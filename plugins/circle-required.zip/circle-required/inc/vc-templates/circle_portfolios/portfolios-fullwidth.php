<div class="bx-gallery__item bx-gallery__item--clearfix <?php circle_portfolio_cat_slug() ?>" data-grid="grid-item">
	<div class="bx-gallery__media">
		<div class="bx-gallery__img is-loading" data-gal="gallery">
			<div data-hover="hoverdir">
				<?php the_post_thumbnail( 'at-portfolio-circle' ); ?>
				<?php if ( get_the_title() || circle_portfolio_cat() ) : ?>
					<div class="info bx-gallery__hover bx-gallery__hover--text-inside">
						<div class="bx-gallery__info">
							<div class="blogs__name text-center">
								<?php if ( get_the_title() ) : ?>
									<?php the_title( '<h2 class="mb-0"><a href="'. get_permalink() .'">', '</a></h2>' ); ?>
								<?php endif ?>
								<?php if ( circle_portfolio_cat() ) : ?>
									<span class="blogs__meta text-uppercase"><?php print ( circle_portfolio_cat() ); // WPCS XSS OK. ?></span>
								<?php endif ?>
							</div>
						</div>
					</div>
				<?php endif ?>
			</div>
		</div>
	</div>
</div><!-- /.bx-gallery__item -->

