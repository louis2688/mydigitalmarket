<?php
/**
 * Template for shortcode circle_brands
 *
 * @package Circle
 */

$atts['_slick_breakpoints'] = isset( $atts['_slick_breakpoints'] ) ? $atts['_slick_breakpoints'] : 'lg:5|md:5|sm:3|xs:1';
$slick_atts = Extras_Composer_Utils::parse_slick_atts( $atts );
$atts = shortcode_atts( array(
	'brands'   => '',
	'el_class' => '',
	'css'      => '',
), $atts );

// Build brands group fields.
$brands = (array) vc_param_group_parse_atts( $atts['brands'] );

$brands = array_map( function ( $brand ) {
	return shortcode_atts( array(
		'logo'             => '',
		'title'            => '',
		'link'             => '',
	), $brand );
}, $brands );

// Don't output anything if see empty $brands.
if ( empty( $brands ) || ( count( $brands ) === 1 && ! $brands[0]['logo'] ) ) {
	return;
}
// Build element classes.
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );
?>
<div class="our-clients__slick clearfix <?php echo esc_attr( $el_class ); ?>" data-fade="false" <?php print $this->build_attributes( $slick_atts ); // WPCS: xss ok. ?>>
	<?php foreach ( $brands as $brand ) :

		if ( empty( $brand['logo'] ) ) {
			continue;
		}
	?>
	<div class="our-clients__item">
		<?php if ( $brand['link'] ) :?>
		<a href="<?php echo esc_url( $brand['link'] );?>" title="<?php echo esc_attr( $brand['title'] );?>">
			<?php echo wp_get_attachment_image( $brand['logo'], 'full' ); ?>
		</a>
		<?php else :?>
			<?php echo wp_get_attachment_image( $brand['logo'], 'full' ); ?>
		<?php endif;?>
	</div>
	<?php endforeach; ?>
</div>
