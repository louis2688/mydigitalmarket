<?php
/**
 * Template for shortcode circle_pagetitle
 *
 * @package Circle
 */

$atts = shortcode_atts( array(
	'size'		 => 'normal',
	'white_mode' => '',
	'underline'  => '',
	'el_class' 	 => '',
	'css'      	 => '',
), $atts );

$vc_class = '';
if ( 'small' == $atts['size'] ) {
	$vc_class .= 'vc_page-title__small ';
}
if ( 'yes' == $atts['white_mode'] ) {
	$vc_class .= 'white ';
}
if ( 'yes' == $atts['underline'] ) {
	$vc_class .= 'vc_page-title__underline ';
}

// Build element classes.
$el_class = $vc_class;
$el_class .= $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );

$_metadata = $page_title_custom = '';
if ( is_tax() || is_archive() ) {
	$_term = get_queried_object();

	if ( $_term && isset( $_term->term_id ) ) {
		$_metadata = get_term_meta( $_term->term_id, 'circle-page-title', true );
	}
} elseif ( is_single() || is_page() ) {
	$_metadata = get_post_meta( get_the_ID(), 'circle-page-title', true );
} elseif ( is_home() ) {
	$_metadata = get_post_meta( get_option('page_for_posts'), 'circle-page-title', true );
}
if ( is_array( $_metadata ) && ! empty( $_metadata['page_title_custom'] ) ) :
	$page_title_custom = $_metadata['page_title_custom'];
endif;
$page_title_custom = str_replace( '|', '<br />', $page_title_custom );
if ( empty( $page_title_custom ) ) {
	return;
}
?>
<h2 class="h1 page-title__name vc_page-title__name <?php echo esc_attr( $el_class ); ?>">
	<?php print $page_title_custom; // Wpcs: xss ok.?>
</h2>
