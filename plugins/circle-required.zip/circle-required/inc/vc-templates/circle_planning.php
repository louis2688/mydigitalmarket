<?php
/**
 * Template for shortcode circle_plannings.
 *
 * @package Circle
 */

$atts = shortcode_atts( array(
	'plannings'   => '',
	'el_class' => '',
	'css'      => '',
), $atts );

// Build brands group fields.
$plannings = (array) vc_param_group_parse_atts( $atts['plannings'] );

$plannings = array_map( function ( $planning ) {
	return shortcode_atts( array(
		'title'            	=> '',
		'content'           => '',
	), $planning );
}, $plannings );

// Don't output anything if see empty $plannings.
if ( empty( $plannings ) ) {
	return;
}

// Build element classes.
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );
?>
<?php foreach ( $plannings as $key => $planning ) :?>
<div class="planning__item <?php echo esc_attr( $el_class ); ?>">
	<?php if ( $planning['title'] ) : ?>
	<h2 class="planning__title h4 bx-content__title bx-content__title--line-left text-uppercase" data-waypoint="waypointEffect">
		<?php echo esc_html( $planning['title'] ); ?>
	</h2>
	<?php endif ?>
	<?php if ( $planning['content'] ) : ?>
	<div class="clearfix">
		<p class="planning_desc"><?php echo esc_html( $planning['content'] ); ?></p>
	</div>
	<?php endif ?>
	<div class="count-number">
		<div class="count-number__item count-number__item--right count-number__item--vcenter count-number__item--rotate" data-waypoint="waypointEffect">
			<?php echo intval( $key + 1 );?>
		</div>
	</div>
</div><!-- /.our-planning__item -->
<?php endforeach;?>
