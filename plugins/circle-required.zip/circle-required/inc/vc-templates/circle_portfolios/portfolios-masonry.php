<?php if ( 0 == ( $index - 2 ) % 6 || 0 == ( $index - 3 ) % 6 ) : ?>

	<div class="bx-gallery__item bx-gallery__item--clearfix bx-gallery__item--width2 <?php circle_portfolio_cat_slug() ?>" data-grid="grid-item">
		<div class="bx-gallery__media">
			<div class="bx-gallery__img is-loading" data-gal="gallery">
				<?php circle_portfolio_thumbnail(); ?>
			</div>
			<?php if ( get_the_title() || circle_portfolio_cat() ) : ?>
			<div class="bx-gallery__info">
				<div class="blogs__name">
				<?php if ( get_the_title() ) : ?>
					<?php the_title( '<h2 class="mb-0"><a href="'. get_permalink() .'">', '</a></h2>' ); ?>
				<?php endif ?>
				<?php if ( circle_portfolio_cat() ) : ?>
					<span class="blogs__meta text-uppercase"><?php print ( circle_portfolio_cat() ); // WPCS XSS OK. ?></span>
				<?php endif ?>
				</div>
			</div>
			<?php endif ?>
		</div>
	</div><!-- /.bx-gallery__item -->

<?php else : ?>

	<div class="bx-gallery__item bx-gallery__item--clearfix <?php circle_portfolio_cat_slug() ?>" data-grid="grid-item">
		<div class="bx-gallery__media">
			<div class="bx-gallery__img is-loading" data-gal="gallery">
				<?php circle_portfolio_thumbnail(); ?>
			</div>
			<?php if ( get_the_title() || circle_portfolio_cat() ) : ?>
			<div class="bx-gallery__info">
				<div class="blogs__name">
				<?php if ( get_the_title() ) : ?>
					<?php the_title( '<h2 class="mb-0"><a href="'. get_permalink() .'">', '</a></h2>' ); ?>
				<?php endif ?>
				<?php if ( circle_portfolio_cat() ) : ?>
					<span class="blogs__meta text-uppercase"><?php print ( circle_portfolio_cat() ); // WPCS XSS OK. ?></span>
				<?php endif ?>
				</div>
			</div>
			<?php endif ?>
		</div>
	</div><!-- /.bx-gallery__item -->

<?php endif; ?>
