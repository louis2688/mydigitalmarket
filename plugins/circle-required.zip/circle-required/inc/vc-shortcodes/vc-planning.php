<?php

/**
 * Circle Planning Visual Composer Shortcode Builder
 */
function vc_circle_planning_config() {
	$params[] = array(
		'type'        => 'param_group',
		'param_name'  => 'plannings',
		'heading'     => esc_html__( 'Planning', 'circle' ),
		'params'      => array(
			array(
				'type'        => 'textfield',
				'param_name'  => 'title',
				'heading'     => esc_html__( 'Title', 'circle' ),
				'admin_label' => true,
			),
			array(
				'type'        => 'textarea',
				'param_name'  => 'content',
				'heading'     => esc_html__( 'Content', 'circle' ),
			),

		),
	);

	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'el_class',
		'heading'     => esc_html__( 'Extra class name', 'circle' ),
	);

	$params[] = array(
		'type'        => 'css_editor',
		'param_name'  => 'css',
		'heading'     => esc_html__( 'CSS box', 'circle' ),
		'group'       => esc_html__( 'Design Options', 'circle' ),
	);

	return array(
		'name'        => esc_html__( 'Planning', 'circle' ),
		'description' => esc_html__( 'Display some plannings.', 'circle' ),
		'icon'        => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'category'    => esc_html__( 'AweThemes', 'circle' ),
		'params'      => $params,
	);
}
vc_lean_map( 'circle_planning', 'vc_circle_planning_config' );

class WPBakeryShortCode_Circle_Planning extends Circle_Shortcode_Abstract {
}
