<?php
/**
 * Team Member Visual Composer Shortcode Builder.
 *
 * @package Circle
 */

/**
 * Register Team member content elemnt
 */
function vcmap_circle_team() {
	$params[] = array(
		'type'        => 'param_group',
		'param_name'  => 'members',
		'heading'     => esc_html__( 'Team Members', 'circle' ),
		'params'      => array(
			array(
				'type'        => 'attach_image',
				'param_name'  => 'avatar',
				'heading'     => esc_html__( 'Avatar', 'circle' ),
			),
			array(
				'type'        => 'textfield',
				'param_name'  => 'name',
				'heading'     => esc_html__( 'Name', 'circle' ),
				'admin_label' => true,
			),
			array(
				'type'        => 'textarea',
				'param_name'  => 'position',
				'heading'     => esc_html__( 'Position', 'circle' ),
				'value'       => '',
			),
		),
	);

	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'el_class',
		'heading'     => esc_html__( 'Extra class name', 'circle' ),
	);

	$params[] = array(
		'type'        => 'css_editor',
		'param_name'  => 'css',
		'heading'     => esc_html__( 'CSS box', 'circle' ),
		'group'       => esc_html__( 'Design Options', 'circle' ),
	);

	$params = array_merge(
		$params,
		VC_Extended_Snippets::slick_params( 'lg:3|md:3|sm:2|xs:1' )
	);

	return array(
		'name'        => esc_html__( 'Team Member', 'circle' ),
		'category'    => esc_html__( 'AweThemes', 'circle' ),
		'description' => esc_html__( 'Display your team member', 'circle' ),
		'icon'        => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'params'      => $params,
	);
}
vc_lean_map( 'circle_team', 'vcmap_circle_team' );

/**
 * WPBakeryShortCode_Circle_Team
 */
class WPBakeryShortCode_Circle_Team extends Circle_Shortcode_Abstract {
}
