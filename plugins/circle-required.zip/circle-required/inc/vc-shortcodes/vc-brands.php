<?php
/**
 * Circle Brands Visual Composer Shortcode Builder
 */
function vcmap_circle_brands() {
	$params[] = array(
		'type'        => 'param_group',
		'param_name'  => 'brands',
		'heading'     => esc_html__( 'Brands', 'circle' ),
		'params'      => array(
			array(
				'type'        => 'attach_image',
				'param_name'  => 'logo',
				'heading'     => esc_html__( 'Logo', 'circle' ),
			),
			array(
				'type'        => 'textfield',
				'param_name'  => 'title',
				'heading'     => esc_html__( 'Title', 'circle' ),
				'admin_label' => true,
			),
			array(
				'type'        => 'textfield',
				'param_name'  => 'link',
				'heading'     => esc_html__( 'Link', 'circle' ),
				'description' => esc_html__( 'Optional: Link to brand website', 'circle' ),
			),
		),
	);

	$params = array_merge(
		$params,
		VC_Extended_Snippets::slick_params( 'lg:5|md:5|sm:3|xs:1' ),
		VC_Extended_Snippets::design_options()
	);

	return array(
		'name'        => esc_html__( 'Brands Carousel', 'circle' ),
		'description' => esc_html__( 'Display a collection of brands', 'circle' ),
		'category'    => esc_html__( 'AweThemes', 'circle' ),
		'icon'        => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'params'      => $params,
	);
}
vc_lean_map( 'circle_brands', 'vcmap_circle_brands' );

class WPBakeryShortCode_Circle_Brands extends Circle_Shortcode_Abstract {
}
