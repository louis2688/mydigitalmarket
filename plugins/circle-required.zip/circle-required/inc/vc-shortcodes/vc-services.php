<?php
/**
 * Register Service box content elemnt
 */
function vcmap_circle_services() {
	$params[] = array(
		'type'        => 'param_group',
		'param_name'  => 'cs_services',
		'heading'     => esc_html__( 'Services', 'circle' ),
		'params'      => array(
			array(
				'type'       => 'dropdown',
				'heading'    => esc_html__( 'Icon library', 'circle' ),
				'value' => array(
					esc_html__( 'Font Awesome', 'circle' )  => 'fontawesome',
					esc_html__( 'Open Iconic', 'circle' )   => 'openiconic',
					esc_html__( 'Typicons', 'circle' )      => 'typicons',
					esc_html__( 'Entypo', 'circle' )        => 'entypo',
					esc_html__( 'Linecons', 'circle' )      => 'linecons',
					esc_html__( 'Mono Social', 'circle' )   => 'monosocial',
					esc_html__( 'Circle Studio', 'circle' ) => 'circle',
				),
				'admin_label' => true,
				'std'         => 'circle',
				'param_name'  => 'icon_type',
				'description' => esc_html__( 'Select icon library.', 'circle' ),
			),

			array(
				'type'          => 'iconpicker',
				'heading'       => esc_html__( 'Icon', 'circle' ),
				'param_name'    => 'icon_fontawesome',
				'value'         => 'fa fa-adjust',
				'settings'      => array(
					'iconsPerPage' => 4000,
				),
				'dependency'   => array(
					'emptyIcon'  => true,
					'element'    => 'icon_type',
					'value'      => 'fontawesome',
				),
				'description' => esc_html__( 'Select icon from library.', 'circle' ),
			),

			array(
				'type'       => 'iconpicker',
				'heading'    => esc_html__( 'Icon', 'circle' ),
				'param_name' => 'icon_openiconic',
				'value'      => 'vc-oi vc-oi-dial',
				'settings'   => array(
					'type'         => 'openiconic',
					'iconsPerPage' => 4000,
				),
				'dependency'   => array(
					'emptyIcon'  => true,
					'element'    => 'icon_type',
					'value'      => 'openiconic',
				),
				'description'  => esc_html__( 'Select icon from library.', 'circle' ),
			),

			array(
				'type'       => 'iconpicker',
				'heading'    => esc_html__( 'Icon', 'circle' ),
				'param_name' => 'icon_typicons',
				'value'      => 'typcn typcn-adjust-brightness',
				'settings'   => array(
					'type'          => 'typicons',
					'iconsPerPage'  => 4000,
				),
				'dependency'  => array(
					'emptyIcon'   => true,
					'element'     => 'icon_type',
					'value'       => 'typicons',
				),
				'description'   => esc_html__( 'Select icon from library.', 'circle' ),
			),

			array(
				'type'        => 'iconpicker',
				'heading'     => esc_html__( 'Icon', 'circle' ),
				'param_name'  => 'icon_entypo',
				'value'       => 'entypo-icon entypo-icon-note',
				'settings'    => array(
					'type'          => 'entypo',
					'iconsPerPage'  => 4000,
				),
				'dependency'  => array(
					'emptyIcon'   => true,
					'element'     => 'icon_type',
					'value'       => 'entypo',
				),
			),

			array(
				'type'        => 'iconpicker',
				'heading'     => esc_html__( 'Icon', 'circle' ),
				'param_name'  => 'icon_linecons',
				'value'       => 'vc_li vc_li-heart',
				'settings'    => array(
					'emptyIcon'    => true,
					'type'         => 'linecons',
					'iconsPerPage' => 4000,
				),
				'dependency'  => array(
					'element'     => 'icon_type',
					'value'       => 'linecons',
				),
				'description' => esc_html__( 'Select icon from library.', 'circle' ),
			),

			array(
				'type'        => 'iconpicker',
				'heading'     => esc_html__( 'Icon', 'circle' ),
				'param_name'  => 'icon_monosocial',
				'value'       => 'vc-mono vc-mono-fivehundredpx',
				'settings'    => array(
					'emptyIcon'    => true,
					'type'         => 'monosocial',
					'iconsPerPage' => 4000,
				),
				'dependency'  => array(
					'element'   => 'icon_type',
					'value'     => 'monosocial',
				),
				'description' => esc_html__( 'Select icon from library.', 'circle' ),
			),

			array(
				'type'        => 'iconpicker',
				'heading'     => esc_html__( 'Icon', 'circle' ),
				'param_name'  => 'icon_circle',
				'value'       => 'cs cs-water',
				'settings'    => array(
					'emptyIcon'    => true,
					'type'         => 'circle',
					'iconsPerPage' => 4000,
				),
				'dependency'  => array(
					'element'   => 'icon_type',
					'value'     => 'circle',
				),
				'description' => esc_html__( 'Select icon from library.', 'circle' ),
			),

			array(
				'type'        => 'colorpicker',
				'param_name'  => 'icon_color',
				'heading'     => esc_html__( 'Icon color', 'circle' ),
				'value'       => '',
			),

			array(
				'type'       => 'dropdown',
				'param_name' => 'bg_type',
				'heading'    => esc_html__( 'Background type', 'circle' ),
				'value'      => array(
					esc_html__( 'Color', 'circle' ) => 'color',
					esc_html__( 'Image', 'circle' ) => 'image',
				),
				'std'        => 'color',
			),

			array(
				'type'        => 'attach_image',
				'param_name'  => 'bg_type_image',
				'heading'     => esc_html__( 'Background image', 'circle' ),
				'value'       => '',
				'dependency'  => array(
					'element'  => 'bg_type',
					'value'    => 'image',
				),
			),

			array(
				'type'        => 'colorpicker',
				'param_name'  => 'bg_type_color',
				'heading'     => esc_html__( 'Background color', 'circle' ),
				'value'       => '',
				'dependency'  => array(
					'element'  => 'bg_type',
					'value'    => 'color',
				),
			),

			array(
				'type'        => 'dropdown',
				'param_name'  => 'bg_filter',
				'heading'     => esc_html__( 'Background filter', 'circle' ),
				'dependency'  => array(
					'element'   => 'bg_type',
					'value'     => 'image',
				),
				'value'       => array(
					esc_html__( 'Blue', 'circle' ) => 'blue',
					esc_html__( 'Pink', 'circle' ) => 'pink',
					esc_html__( 'Orange', 'circle' ) => 'orange',
					esc_html__( 'Custom', 'circle' ) => 'custom',
				),
			),

			array(
				'type'        => 'colorpicker',
				'param_name'  => 'custom_filter',
				'heading'     => esc_html__( 'Background filter', 'circle' ),
				'value'       => '',
				'dependency'  => array(
					'element'   => 'bg_filter',
					'value'     => 'custom',
				),
			),

			array(
				'type'       => 'textfield',
				'param_name' => 'sv_name',
				'heading'    => esc_html__( 'Service *', 'circle' ),
				'value'      => '',
			),

			array(
				'type'       => 'textfield',
				'param_name' => 'sv_areas',
				'heading'    => esc_html__( 'Intervention areas', 'circle' ),
				'value'      => '',
			),

			array(
				'type'       => 'textarea',
				'param_name' => 'sv_description',
				'heading'    => esc_html__( 'Service description', 'circle' ),
			),

			array(
				'type'        => 'textarea',
				'param_name'  => 'sv_list',
				'heading'     => esc_html__( 'List of services', 'circle' ),
				'description' => '"|" as "< /br >" tag.',
			),
		),
	);

	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'el_class',
		'heading'     => esc_html__( 'Extra class name', 'circle' ),
	);

	$params[] = array(
		'type'        => 'css_editor',
		'param_name'  => 'css',
		'heading'     => esc_html__( 'CSS box', 'circle' ),
		'group'       => esc_html__( 'Design Options', 'circle' ),
	);

	return array(
		'name'     => esc_html__( 'Services', 'circle' ),
		'icon'     => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'category' => esc_html__( 'AweThemes', 'circle' ),
		'params'   => $params,
		'js_view'  => 'VcIconElementView_Backend',
	);
}
vc_lean_map( 'circle_services', 'vcmap_circle_services' );

/**
 * Services content element extends Circle_Shortcode_Abstract class
 */
class WPBakeryShortCode_Circle_Services extends Circle_Shortcode_Abstract {

}
