<?php

class Circle_Shortcode_Abstract extends WPBakeryShortCode_Extended {

	/**
	 * Constructor of class.
	 *
	 * @param array $settings
	 */
	public function __construct( $settings ) {
		parent::__construct( $settings );

		$this->template_directory = CIRCLE_PLUGIN_PATH . 'inc/vc-templates';
	}
}
