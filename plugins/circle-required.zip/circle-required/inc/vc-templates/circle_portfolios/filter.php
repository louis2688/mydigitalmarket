<nav class="bx-filters group-filter text-center text-uppercase mb-80" data-type="filter-isotope">
<?php

	printf(
		'<a class="current" title="" href="#" data-filter="*">%s <span class="portfolios_count"></span></a>',
	 	esc_html__( 'All', 'circle' )
	);

	foreach ( $ids as $term_id ) {
		$term = get_term_by( 'term_id', $term_id, 'at_portfolio_cat' );

		if ( ! $term || is_wp_error( $term ) ) {
			continue;
		}

		printf(
			'<a href="#" title="" data-filter=".%s">%s <span class="portfolios_count"></span></a>',
			esc_attr( $term->slug ),
			esc_html( $term->name )
		);
	}
?>
</nav>

