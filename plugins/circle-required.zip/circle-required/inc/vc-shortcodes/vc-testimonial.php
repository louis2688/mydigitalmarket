<?php
/**
 * Shortcode circle_testimonial_carousel
 *
 * @package Circle
 */

function vcmap_circle_testimonial() {
	$params = array(
		// Data settings.
		array(
			'type'        => 'textfield',
			'param_name'  => 'posts_per_page',
			'heading'     => esc_html__( 'Total (Limit) items', 'circle' ),
			'description' => esc_html__( 'Set max limit for items or enter -1 to display all.', 'circle' ),
			'std'         => 10,
		),
		array(
			'type'       => 'dropdown',
			'param_name' => 'orderby',
			'heading'    => esc_html__( 'Order by', 'circle' ),
			'std'        => 'date',
			'value'      => array(
				esc_html__( 'Date', 'circle' )                  => 'date',
				esc_html__( 'Order by post ID', 'circle' )      => 'ID',
				esc_html__( 'Author', 'circle' )                => 'author',
				esc_html__( 'Last modified date', 'circle' )    => 'modified',
				esc_html__( 'Post/page parent ID', 'circle' )   => 'parent',
				esc_html__( 'Random order', 'circle' )          => 'rand',
			),
		),
		array(
			'type'       => 'dropdown',
			'param_name' => 'order',
			'heading'    => esc_html__( 'Sort order', 'circle' ),
			'std'        => 'DESC',
			'value'      => array(
				esc_html__( 'Descending', 'circle' ) => 'DESC',
				esc_html__( 'Ascending', 'circle' )  => 'ASC',
			),
		),
	);

	$params = array_merge(
		$params,
		VC_Extended_Snippets::slick_params( 'lg:1|md:1|sm:1|xs:1' ),
		VC_Extended_Snippets::design_options()
	);

	return array(
		'name'        => esc_html__( 'Testimonial', 'circle' ),
		'description' => esc_html__( 'Testimonial', 'circle' ), // TODO:
		'category'    => esc_html__( 'AweThemes', 'circle' ),
		'icon'        => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'params'      => $params,
	);
}
vc_lean_map( 'circle_testimonial', 'vcmap_circle_testimonial' );

/**
 * Circle_Shortcode_Testimonial_Base
 */
class Circle_Shortcode_Testimonial_Base extends Circle_Shortcode_Abstract {
	/**
	 * Build the WP_Query.
	 *
	 * @param  array $atts
	 * @return WP_Query
	 */
	protected function buildWPQuery( $atts ) {
		$args = shortcode_atts( array(
			'post_type' => 'at-testimonial',
			'orderby'   => 'date',
			'order'     => 'DESC',
			'posts_per_page' => 10,
		), $atts );

		return new WP_Query( $args );
	}
}

class WPBakeryShortCode_Circle_Testimonial extends Circle_Shortcode_Testimonial_Base {
}
