<?php
/**
 * Template for shortcode circle image
 *
 * @package Circle
 */

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

if ( ! wp_get_attachment_image_src( $atts['image'] ) ) {
	return;
}

// Set circle type
if ( '12' == $atts['type'] ) {
	$circle_style = 'background-image: url('. get_template_directory_uri() .'/img/cricle_12.png)';
} elseif ( '0' == $atts['type'] ) {
	$circle_url = wp_get_attachment_image_url( $atts['circle_image'] );
	$circle_style = $circle_url ? 'background-image: url('. $circle_url .')':'';
} else {
	$circle_style = 'background-image: url('. get_template_directory_uri() .'/img/cricle_11.png)';
}

// Build element classes.
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );

?>
<div class="our-history__img <?php echo esc_attr( $el_class ); ?>">
	<?php echo wp_get_attachment_image( $atts['image'], 'full' ); ?>
	<?php if ( $circle_style ): ?>
		<span class="our-history__circle" style="<?php echo esc_attr( $circle_style ); ?>"></span>
	<?php endif ?>
</div>
