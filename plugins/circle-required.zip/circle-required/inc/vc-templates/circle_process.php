<?php
/**
 * Template for shortcode circle_process.
 *
 * @package Circle
 */

$atts = shortcode_atts( array(
	'process'   => '',
	'el_class' => '',
	'css'      => '',
), $atts );

// Build brands group fields.
$process = (array) vc_param_group_parse_atts( $atts['process'] );

$process = array_map( function ( $proc ) {
	return shortcode_atts( array(
		'image'             => '',
		'title'            	=> '',
		'content'           => '',
	), $proc );
}, $process );

// Don't output anything if see empty $process.
if ( empty( $process ) || ( count( $process ) === 1 && ! $process[0]['image'] ) ) {
	return;
}

// Build element classes.
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );
?>
<div class="bx-process__slick bx-process__wrap <?php echo esc_attr( $el_class ); ?>" data-init="slick" data-fade="false" data-breakpoints='{"lg": 1, "md": 1, "sm": 2, "xs": 1}'>
	<?php foreach ( $process as $key => $proc ) :

		if ( empty( $proc['image'] ) ) {
			continue;
		}
	?>
	<div class="bx-process__item">
		<div class="row">
			<div class="col-md-6">
				<div class="bx-process__media">
					<?php echo wp_get_attachment_image( $proc['image'], 'full' ); ?>
				</div>
			</div>
			<div class="col-md-6">
				<div class="bx-process__info">
					<div class="bx-process__header mb-60">
						<span class="bx-process__count black"><?php printf( "%02d\n", $key + 1 ); // Wpcs: xss ok.?></span>
						<?php if ( $proc['title'] ) : ?>
						<h2 class="bx-process__title bx-content__title bx-content__title--line-left text-uppercase black mb-0" data-waypoint="waypointEffect"><?php echo esc_html( $proc['title'] ); ?></h2>
						<?php endif ?>
					</div>
					<?php if ( $proc['content'] ) : ?>
					<p class="bx-process__desc mb-0"><?php echo esc_html( $proc['content'] ); ?></p>
					<?php endif ?>
				</div>
			</div>
		</div>
	</div><!-- /.bx-process__item -->
	<?php endforeach;?>
</div><!-- /.bx-process__slick -->
