<?php
/**
 * Template for the circle_service shortcode.
 *
 * @package Circle
 */

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

// Build services group fields.
$services = (array) vc_param_group_parse_atts( $atts['cs_services'] );

$services = array_map( function ( $service ) {
	return shortcode_atts( array(
		'icon_type'         => 'circle',
		'icon_color'        => '',
		'bg_type'           => 'color',
		'bg_type_image'     => '',
		'bg_type_color'     => '',
		'bg_filter'         => 'blue',
		'custom_filter'     => '',
		'sv_name'           => '',
		'sv_areas'          => '',
		'sv_description'    => '',
		'sv_list'           => '',
		'icon_fontawesome'  => '',
		'icon_openiconic'   => '',
		'icon_typicons'     => '',
		'icon_entypo'       => '',
		'icon_entypo'       => '',
		'icon_linecons'     => '',
		'icon_monosocial'   => '',
		'icon_circle'       => '',
	), $service );
}, $services );

// Return if empty $services
if ( empty( $services ) ) {
	return;
}

// Build class
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );
$icon_css = array();
?>

<div class="<?php echo esc_attr( $el_class ); ?>">
<?php foreach ( $services as $service ) : ?>

	<?php
	// Check service name
	if ( ! trim( $service['sv_name'] ) ) {
		continue;
	}

	// Enqueue needed icon font.
	if ( ! in_array( $service['icon_type'], $icon_css ) ) {
		$icon_css[] = $service['icon_type'];
		vc_icon_element_fonts_enqueue( $service['icon_type'] );
	}

	// Get icon_type
	$icon_type = 'icon_' . $service['icon_type'];

	// Icon color
	if ( $service['icon_color'] ) {
		$icon_color = 'color: '. $service['icon_color'] .'';
	}
	// Get background
	if ( 'image' === $service['bg_type'] ) {
		$background = 'background-image: url('. wp_get_attachment_image_url( $service['bg_type_image'], 'full' ) .')';
	} else {
		$background = 'background-color: '. $service['bg_type_color'];
	}

	// Get background filter
	if ( 'image' === $service['bg_type'] ) {

		if ( 'custom' === $service['bg_filter'] ) {
			$bg_filter = 'background-color: '. $service['custom_filter'];

		} elseif ( 'blue' === $service['bg_filter'] ) {
			$link = plugin_dir_url( __FILE__ ) . '/circle_services/blue.png';
			$bg_filter = 'background: url('. esc_url( $link ) .') no-repeat; background-size: cover';

		} elseif ( 'pink' === $service['bg_filter'] ) {
			$link = plugin_dir_url( __FILE__ ) . '/circle_services/pink.png';
			$bg_filter = 'background: url('. esc_url( $link ) .') no-repeat; background-size: cover';

		} elseif ( 'orange' === $service['bg_filter'] ) {
			$link = plugin_dir_url( __FILE__ ) . '/circle_services/orange.png';
			$bg_filter = 'background: url('. esc_url( $link ) .') no-repeat; background-size: cover';
		}
	}

	?>

	<div class="craft-digital__item">
		<div class="craft-digital__media">
			<div class="craft-digital__img craft-digital__img--bg-blue">
			<?php if ( 'image' === $service['bg_type'] && $service['bg_filter'] ) : ?>
				<span class="craft-digital__img--bg" style="<?php echo esc_attr( $bg_filter ); ?>;"></span>
			<?php endif ?>
			<?php if ( $service['bg_type_image'] || $service['bg_type_color'] ) : ?>
				<span class="img" style="<?php echo esc_attr( $background ); ?>"></span>
			<?php endif ?>
			<?php if ( $service[ $icon_type ] ) : ?>
				<span class="craft-degital__icon" style="<?php echo esc_attr( $icon_color ); ?>"><i class="<?php echo esc_attr( $service[ $icon_type ] ); ?>"></i></span>
			<?php endif ?>

			</div><!-- /.craft-digital__img -->
		</div>
		<div class="craft-digital__info">
			<h2 class="craft-digital__title h4 bx-content__title bx-content__title--line-left text-uppercase mb-20" data-waypoint="waypointEffect"><?php echo esc_html( $service['sv_name'] ); ?></h2>

			<?php if ( trim( $service['sv_areas'] ) ) : ?>
				<p class="craft-digital__areas text-uppercase mb-20"><?php echo esc_html( trim( $service['sv_areas'] ) ); ?></p>
			<?php endif ?>

			<?php if ( trim( $service['sv_description'] ) ) : ?>
				<p class="craft-digital__desc mb-25"><?php print( wpautop( $service['sv_description'] ) ); // WPCS: XSS OK. ?></p>
			<?php endif ?>

			<?php if ( trim( $service['sv_list'] ) ) : ?>
				<?php circle_service_list( $service['sv_list'] ); ?>
			<?php endif ?>

		</div>

	</div><!-- /.our-history__item -->

<?php endforeach ?>
</div>



