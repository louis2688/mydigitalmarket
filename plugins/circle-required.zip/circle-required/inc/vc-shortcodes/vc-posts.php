<?php
/**
 * Circle Posts Visual Composer Shortcode Builder
 *
 * @package Circle
 */

if ( ! function_exists( 'circle_posts_carousel_time' ) ) :
	/**
	 * Prints HTML with meta information for the current post-date/time and author.
	 */
	function circle_posts_carousel_time() {
		$time_string = '<time class="entry-date published updated" datetime="%1$s">%2$s</time>';
		if ( get_the_time( 'U' ) !== get_the_modified_time( 'U' ) ) {
			$time_string = '<time class="entry-date published" datetime="%1$s">%2$s</time><time class="updated" datetime="%3$s">%4$s</time>';
		}

		$time_string = sprintf( $time_string,
			esc_attr( get_the_date( 'c' ) ),
			esc_html( get_the_date() ),
			esc_attr( get_the_modified_date( 'c' ) ),
			esc_html( get_the_modified_date() )
		);

		echo '<span class="blogs__meta text-uppercase">' . $time_string . '</span>'; // WPCS: XSS OK.
	}
endif;

/**
 * //
 */
function vc_circle_posts_config() {
	$params = array(
		array(
			'type' 			=> 'loop',
			'heading' 		=> esc_html__( 'Query', 'circle' ),
			'param_name' 	=> 'loop',
			'value' 		=> 'size:10|order_by:date',
			'settings' 		=> array(
				'size' 		=> array( 'hidden' => false, 'value' => 10 ),
				'order_by' 	=> array( 'value' => 'date' ),
				'post_type' => array( 'hidden' => false ),
				'tax_query' => array( 'hidden' => false ),
			),
			'description' => esc_html__( 'Create WordPress loop, to populate content from your site.', 'circle' ),
		),
	);

	$params = array_merge(
		$params,
		VC_Extended_Snippets::slick_params( 'lg:3|md:3|sm:2|xs:1' ),
		VC_Extended_Snippets::design_options()
	);

	return array(
		'name'        => esc_html__( 'Posts Carousel', 'circle' ),
		'icon'        => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'category'    => esc_html__( 'AweThemes', 'circle' ),
		'description' => esc_html__( 'Display Posts, pages or custom posts as carousel', 'circle' ),
		'params'      => $params,
	);
}
vc_lean_map( 'vc_circle_posts', 'vc_circle_posts_config' );

/**
 * WPBakeryShortCode_VC_Circle_Posts class.
 */
class WPBakeryShortCode_VC_Circle_Posts extends Circle_Shortcode_Abstract {
}
