<div class="features-home__item clearfix <?php circle_portfolio_cat_slug() ?>" data-grid="grid-item">
	<div class="features-home__img" data-waypoint="waypointEffect">
		<?php the_post_thumbnail( 'at-portfolio-rectangle' ); ?>
		<a href="<?php the_permalink(); ?>" class="cs-icon"></a>
		<span class="features-home__img--bg"></span>
	</div>
	<?php if ( get_the_title() || circle_portfolio_cat() ) : ?>
		<div class="features-home__info pt-110">
		<?php if ( get_the_title() ) : ?>
			<h2 class="features-home__title bx-content__title bx-content__title--line-top" data-waypoint="waypointEffect">
				<a href="<?php the_permalink(); ?>" title=""><?php the_title(); ?></a>
			</h2>
		<?php endif ?>
		<?php if ( circle_portfolio_cat() ) : ?>
			<span class="features-home__category"><?php print ( circle_portfolio_cat() ); // WPCS XSS OK. ?></span>
		<?php endif ?>
		</div>
	<?php endif ?>

</div><!-- /.features-home__item -->
