<?php

// Remove param
$params_remove = array( 'color', 'custom_color', 'background_style', 'background_color', 'custom_background_color', 'size', 'align', 'link', 'css_animation', 'el_class', 'css' );
foreach ( $params_remove as $param_remove ) {
	vc_remove_param( 'vc_icon', $param_remove );
};

// Add param
$attributes = array(
	array(
		'type'        => 'dropdown',
		'heading'     => __( 'Icon library', 'js_composer' ),
		'value'       => array(
			__( 'Font Awesome', 'js_composer' )   => 'fontawesome',
			__( 'Open Iconic', 'js_composer' )    => 'openiconic',
			__( 'Typicons', 'js_composer' )       => 'typicons',
			__( 'Entypo', 'js_composer' )         => 'entypo',
			__( 'Linecons', 'js_composer' )       => 'linecons',
			__( 'Mono Social', 'js_composer' )    => 'monosocial',
			__( 'Simple Line', 'js_composer' )    => 'simpleline',
			__( 'Circle', 'js_composer' )         => 'circle',
		),
		'admin_label' => true,
		'param_name'  => 'type',
		'description' => __( 'Select icon library.', 'js_composer' ),
	),

	array(
		'type'         => 'iconpicker',
		'heading'      => __( 'Icon', 'js_composer' ),
		'param_name'   => 'icon_simpleline',
		'value'        => 'icon-diamond',
		'settings'     => array(
			'emptyIcon'    => false,
			'iconsPerPage' => 4000,
			'type'         => 'simpleline',
		),
		'dependency'   => array(
			'element'    => 'type',
			'value'      => 'simpleline',
		),
		'description'  => __( 'Select icon from library.', 'js_composer' ),
	),

	array(
		'type'         => 'iconpicker',
		'heading'      => __( 'Icon', 'js_composer' ),
		'param_name'   => 'icon_circle',
		'value'        => 'cs cs-water',
		'settings'     => array(
			'emptyIcon'    => false,
			'iconsPerPage' => 4000,
			'type'         => 'circle',
		),
		'dependency'   => array(
			'element'    => 'type',
			'value'      => 'circle',
		),
		'description'  => __( 'Select icon from library.', 'js_composer' ),
	),

	array(
		'type'               => 'dropdown',
		'heading'            => __( 'Icon color', 'js_composer' ),
		'param_name'         => 'color',
		'value'              => array_merge( getVcShared( 'colors' ), array( __( 'Custom color', 'js_composer' ) => 'custom' ) ),
		'description'        => __( 'Select icon color.', 'js_composer' ),
		'param_holder_class' => 'vc_colored-dropdown',
	),

	array(
		'type'          => 'colorpicker',
		'heading'       => __( 'Custom color', 'js_composer' ),
		'param_name'    => 'custom_color',
		'description'   => __( 'Select custom icon color.', 'js_composer' ),
		'dependency'    => array(
			'element' => 'color',
			'value'   => 'custom',
		),
	),

	array(
		'type'        => 'dropdown',
		'heading'     => __( 'Background shape', 'js_composer' ),
		'param_name'  => 'background_style',
		'value'       => array(
			__( 'None', 'js_composer' )            => '',
			__( 'Circle', 'js_composer' )          => 'rounded',
			__( 'Square', 'js_composer' )          => 'boxed',
			__( 'Rounded', 'js_composer' )         => 'rounded-less',
			__( 'Outline Circle', 'js_composer' )  => 'rounded-outline',
			__( 'Outline Square', 'js_composer' )  => 'boxed-outline',
			__( 'Outline Rounded', 'js_composer' ) => 'rounded-less-outline',
		),
		'description' => __( 'Select background shape and style for icon.', 'js_composer' ),
	),

	array(
		'type'               => 'dropdown',
		'heading'            => __( 'Background color', 'js_composer' ),
		'param_name'         => 'background_color',
		'value'              => array_merge( getVcShared( 'colors' ), array( __( 'Custom color', 'js_composer' ) => 'custom' ) ),
		'std'                => 'grey',
		'description'        => __( 'Select background color for icon.', 'js_composer' ),
		'param_holder_class' => 'vc_colored-dropdown',
		'dependency'         => array(
			'element'   => 'background_style',
			'not_empty' => true,
		),
	),

	array(
		'type'         => 'colorpicker',
		'heading'      => __( 'Custom background color', 'js_composer' ),
		'param_name'   => 'custom_background_color',
		'description'  => __( 'Select custom icon background color.', 'js_composer' ),
		'dependency'   => array(
			'element'   => 'background_color',
			'value'     => 'custom',
		),
	),

	array(
		'type'        => 'dropdown',
		'heading'     => __( 'Size', 'js_composer' ),
		'param_name'  => 'size',
		'value'       => array_merge( getVcShared( 'sizes' ), array( 'Extra Large' => 'xl' ) ),
		'std'         => 'md',
		'description' => __( 'Icon size.', 'js_composer' ),
	),

	array(
		'type'        => 'dropdown',
		'heading'     => __( 'Icon alignment', 'js_composer' ),
		'param_name'  => 'align',
		'value'       => array(
			__( 'Left', 'js_composer' )   => 'left',
			__( 'Right', 'js_composer' )  => 'right',
			__( 'Center', 'js_composer' ) => 'center',
		),
		'description' => __( 'Select icon alignment.', 'js_composer' ),
	),

	array(
		'type'        => 'vc_link',
		'heading'     => __( 'URL (Link)', 'js_composer' ),
		'param_name'  => 'link',
		'description' => __( 'Add link to icon.', 'js_composer' ),
	),
	vc_map_add_css_animation(),

	array(
		'type'        => 'textfield',
		'heading'     => __( 'Extra class name', 'js_composer' ),
		'param_name'  => 'el_class',
		'description' => __( 'Style particular content element differently - add a class name and refer to it in custom CSS.', 'js_composer' ),
	),

	array(
		'type'       => 'css_editor',
		'heading'    => __( 'CSS box', 'js_composer' ),
		'param_name' => 'css',
		'group'      => __( 'Design Options', 'js_composer' ),
	),
);
vc_add_params( 'vc_icon', $attributes );

/**
 * Update icon type: circle icon
 */
function vcmap_iconpicker_type_circle( $icons ) {
	$circle_icon = array(
		array( 'cs cs-arrow-down' => 'arrow down' ),
		array( 'cs cs-arrow-left' => 'arrow left' ),
		array( 'cs cs-arrow-right' => 'arrow right' ),
		array( 'cs cs-compass' => 'compass' ),
		array( 'cs cs-engineering' => 'engineering' ),
		array( 'cs cs-water' => 'water' ),
	);
	return array_merge( $icons, $circle_icon );
};
add_filter( 'vc_iconpicker-type-circle', 'vcmap_iconpicker_type_circle' );

/**
 * Register Css for circle font
 */
function vc_iconpicker_circle_register_css() {
	wp_enqueue_style( 'cs-circle-icon', get_template_directory_uri() . '/css/cs-icons.css' );
}
add_action( 'vc_base_register_admin_css', 'vc_iconpicker_circle_register_css' );

/**
 * Update icon type: simple-line-icons
 */
function vcmap_iconpicker_type_simpleline( $icons ) {
	$circle_icon = array(
		array( 'icon-user' => 'User' ),
		array( 'icon-people' => 'People' ),
		array( 'icon-user-female' => 'User female' ),
		array( 'icon-user-follow' => 'User follow' ),
		array( 'icon-user-following' => 'User following' ),
		array( 'icon-user-unfollow' => 'User unfollow' ),
		array( 'icon-login' => 'Login' ),
		array( 'icon-logout' => 'Logout' ),
		array( 'icon-emotsmile' => 'Emotsmile' ),
		array( 'icon-phone' => 'Phone' ),
		array( 'icon-call-end' => 'Call end' ),
		array( 'icon-call-in' => 'Call in' ),
		array( 'icon-call-out' => 'Call out' ),
		array( 'icon-location-pin' => 'Location pin' ),
		array( 'icon-direction' => 'Direction' ),
		array( 'icon-directions' => 'Directions' ),
		array( 'icon-compass' => 'Compass' ),
		array( 'icon-layers' => 'Layers' ),
		array( 'icon-menu' => 'Menu' ),
		array( 'icon-list' => 'List' ),
		array( 'icon-options-vertical' => 'Options vertical' ),
		array( 'icon-options' => 'Options' ),
		array( 'icon-arrow-down' => 'Arrow down' ),
		array( 'icon-arrow-left' => 'Arrow left' ),
		array( 'icon-arrow-right' => 'Arrow right' ),
		array( 'icon-arrow-up' => 'Arrow up' ),
		array( 'icon-arrow-up-circle' => 'Arrow up circle' ),
		array( 'icon-arrow-left-circle' => 'Arrow left circle' ),
		array( 'icon-arrow-right-circle' => 'Arrow right circle' ),
		array( 'icon-arrow-down-circle' => 'Arrow down circle' ),
		array( 'icon-check' => 'check' ),
		array( 'icon-clock' => 'clock' ),
		array( 'icon-plus' => 'plus' ),
		array( 'icon-minus' => 'minus' ),
		array( 'icon-close' => 'close' ),
		array( 'icon-exclamation' => 'exclamation' ),
		array( 'icon-organization' => 'organization' ),
		array( 'icon-trophy' => 'trophy' ),
		array( 'icon-screen-smartphone' => 'screen smartphone' ),
		array( 'icon-screen-desktop' => 'screen desktop' ),
		array( 'icon-plane' => 'plane' ),
		array( 'icon-notebook' => 'notebook' ),
		array( 'icon-mustache' => 'mustache' ),
		array( 'icon-mouse' => 'mouse' ),
		array( 'icon-magnet' => 'magnet' ),
		array( 'icon-energy' => 'energy' ),
		array( 'icon-disc' => 'disc' ),
		array( 'icon-cursor' => 'cursor' ),
		array( 'icon-cursor-move' => 'cursor move' ),
		array( 'icon-crop' => 'crop' ),
		array( 'icon-chemistry' => 'chemistry' ),
		array( 'icon-speedometer' => 'speedometer' ),
		array( 'icon-shield' => 'shield' ),
		array( 'icon-screen-tablet' => 'screen tablet' ),
		array( 'icon-magic-wand' => 'magic wand' ),
		array( 'icon-hourglass' => 'hourglass' ),
		array( 'icon-graduation' => 'graduation' ),
		array( 'icon-ghost' => 'ghost' ),
		array( 'icon-game-controller' => 'game controller' ),
		array( 'icon-eyeglass' => 'eyeglass' ),
		array( 'icon-envelope-open' => 'envelope open' ),
		array( 'icon-envelope-letter' => 'envelope letter' ),
		array( 'icon-bell' => 'bell' ),
		array( 'icon-badge' => 'badge' ),
		array( 'icon-anchor' => 'anchor' ),
		array( 'icon-wallet' => 'wallet' ),
		array( 'icon-vector' => 'vector' ),
		array( 'icon-speech' => 'speech' ),
		array( 'icon-puzzle' => 'puzzle' ),
		array( 'icon-printer' => 'printer' ),
		array( 'icon-present' => 'present' ),
		array( 'icon-playlist' => 'playlist' ),
		array( 'icon-pin' => 'pin' ),
		array( 'icon-picture' => 'picture' ),
		array( 'icon-handbag' => 'handbag' ),
		array( 'icon-globe-alt' => 'globe alt' ),
		array( 'icon-globe' => 'globe' ),
		array( 'icon-folder-alt' => 'folder alt' ),
		array( 'icon-folder' => 'folder' ),
		array( 'icon-film' => 'film' ),
		array( 'icon-feed' => 'feed' ),
		array( 'icon-drop' => 'drop' ),
		array( 'icon-drawer' => 'drawer' ),
		array( 'icon-docs' => 'docs' ),
		array( 'icon-doc' => 'doc' ),
		array( 'icon-diamond' => 'diamond' ),
		array( 'icon-cup' => 'cup' ),
		array( 'icon-bubbles' => 'bubbles' ),
		array( 'icon-briefcase' => 'briefcase' ),
		array( 'icon-book-open' => 'book open' ),
		array( 'icon-basket-loaded' => 'basket loaded' ),
		array( 'icon-basket' => 'basket' ),
		array( 'icon-bag' => 'bag' ),
		array( 'icon-action-undo' => 'action undo' ),
		array( 'icon-action-redo' => 'action redo' ),
		array( 'icon-wrench' => 'wrench' ),
		array( 'icon-umbrella' => 'umbrella' ),
		array( 'icon-trash' => 'trash' ),
		array( 'icon-tag' => 'tag' ),
		array( 'icon-support' => 'support' ),
		array( 'icon-frame' => 'frame' ),
		array( 'icon-size-fullscreen' => 'size fullscreen' ),
		array( 'icon-size-actual' => 'size actual' ),
		array( 'icon-shuffle' => 'shuffle' ),
		array( 'icon-share-alt' => 'share alt' ),
		array( 'icon-share' => 'share' ),
		array( 'icon-rocket' => 'rocket' ),
		array( 'icon-question' => 'question' ),
		array( 'icon-pie-chart' => 'pie chart' ),
		array( 'icon-pencil' => 'pencil' ),
		array( 'icon-note' => 'note' ),
		array( 'icon-loop' => 'loop' ),
		array( 'icon-home' => 'home' ),
		array( 'icon-grid' => 'grid' ),
		array( 'icon-graph' => 'graph' ),
		array( 'icon-music-tone-alt' => 'music tone alt' ),
		array( 'icon-music-tone' => 'music tone' ),
		array( 'icon-earphones-alt' => 'earphones alt' ),
		array( 'icon-earphones' => 'earphones' ),
		array( 'icon-equalizer' => 'equalizer' ),
		array( 'icon-like' => 'like' ),
		array( 'icon-dislike' => 'dislike' ),
		array( 'icon-control-start' => 'control start' ),
		array( 'icon-control-rewind' => 'control rewind' ),
		array( 'icon-control-play' => 'control play' ),
		array( 'icon-control-pause' => 'control pause' ),
		array( 'icon-control-forward' => 'control forward' ),
		array( 'icon-control-end' => 'control end' ),
		array( 'icon-volume-1' => 'volume 1' ),
		array( 'icon-volume-2' => 'volume 2' ),
		array( 'icon-volume-off' => 'volume off' ),
		array( 'icon-calendar' => 'calendar' ),
		array( 'icon-bulb' => 'bulb' ),
		array( 'icon-chart' => 'chart' ),
		array( 'icon-ban' => 'ban' ),
		array( 'icon-bubble' => 'bubble' ),
		array( 'icon-camrecorder' => 'camrecorder' ),
		array( 'icon-camera' => 'camera' ),
		array( 'icon-cloud-download' => 'cloud download' ),
		array( 'icon-cloud-upload' => 'cloud upload' ),
		array( 'icon-envelope' => 'envelope' ),
		array( 'icon-eye' => 'eye' ),
		array( 'icon-flag' => 'flag' ),
		array( 'icon-heart' => 'heart' ),
		array( 'icon-info' => 'info' ),
		array( 'icon-key' => 'key' ),
		array( 'icon-link' => 'link' ),
		array( 'icon-lock' => 'lock' ),
		array( 'icon-lock-open' => 'lock open' ),
		array( 'icon-magnifier' => 'magnifier' ),
		array( 'icon-magnifier-add' => 'magnifier add' ),
		array( 'icon-magnifier-remove' => 'magnifier remove' ),
		array( 'icon-paper-clip' => 'paper clip' ),
		array( 'icon-paper-plane' => 'paper plane' ),
		array( 'icon-refresh' => 'refresh' ),
		array( 'icon-reload' => 'reload' ),
		array( 'icon-settings' => 'settings' ),
		array( 'icon-star' => 'star' ),
		array( 'icon-symbol-female' => 'symbol female' ),
		array( 'icon-symbol-male' => 'symbol male' ),
		array( 'icon-target' => 'target' ),
		array( 'icon-credit-card' => 'credit card' ),
		array( 'icon-paypal' => 'paypal' ),
		array( 'icon-social-tumblr' => 'social tumblr' ),
		array( 'icon-social-twitter' => 'social twitter' ),
		array( 'icon-social-facebook' => 'social facebook' ),
		array( 'icon-social-instagram' => 'social instagram' ),
		array( 'icon-social-linkedin' => 'social linkedin' ),
		array( 'icon-social-pinterest' => 'social pinterest' ),
		array( 'icon-social-github' => 'social github' ),
		array( 'icon-social-google' => 'social google' ),
		array( 'icon-social-reddit' => 'social reddit' ),
		array( 'icon-social-skype' => 'social skype' ),
		array( 'icon-social-dribbble' => 'social dribbble' ),
		array( 'icon-social-behance' => 'social behance' ),
		array( 'icon-social-foursqare' => 'social foursqare' ),
		array( 'icon-social-soundcloud' => 'social soundcloud' ),
		array( 'icon-social-spotify' => 'social spotify' ),
		array( 'icon-social-stumbleupon' => 'social stumbleupon' ),
		array( 'icon-social-youtube' => 'social youtube' ),
		array( 'icon-social-dropbox' => 'social dropbox' ),
	);
	return array_merge( $icons, $circle_icon );
};
add_filter( 'vc_iconpicker-type-simpleline', 'vcmap_iconpicker_type_simpleline' );

/**
 * Register Css for circle font
 */
function vc_iconpicker_simpleline_register_css() {
	wp_enqueue_style( 'cs-simple-line-icon', get_template_directory_uri() . '/css/simple-line-icons.css' );
}
add_action( 'vc_base_register_admin_css', 'vc_iconpicker_simpleline_register_css' );
