<?php
/**
 * Circle plugin functions
 *
 * @package Circle
 */
function circle_portfolio_cat() {
	$term_list = get_the_term_list( get_the_ID(), 'at_portfolio_cat', '<span>', ' / ', '</span>' );

	return wp_kses( $term_list, array( '' => array() ) );
}
function circle_portfolio_cat_slug() {
	$terms = get_the_terms( get_the_ID(), 'at_portfolio_cat' );

	$css_class = array();

	if ( ! $terms || is_wp_error( $terms ) ) {
		return '';
	}

	foreach ( $terms as $term ) {
		$css_class[] = $term->slug;
	}

	echo esc_attr( implode( ' ', $css_class ) );
}

function circle_portfolio_thumbnail( $size = 'at-portfolio-circle' ) {
	?>
	<a href="<?php the_post_thumbnail_url( 'full' ); ?>" data-img="popup" data-hover="hoverdir">
		<?php the_post_thumbnail( $size ); ?>
		<div class="bx-gallery__hover"></div>
	</a>
	<?php
}

function circle_portfolio_layout( $layout, $el_class = null ) {
	if ( 'circle' === $layout ) {
		$layout_return = 'portfolio-cricle' . $el_class;
	} elseif ( 'fullwidth' === $layout ) {
		$layout_return = 'portfolio-fullwidth' . $el_class;
	} elseif ( 'masonry' === $layout ) {
		$layout_return = 'portfolio-masonry' . $el_class;
	} elseif ( 'grid' === $layout ) {
		$layout_return = 'portfolio-standart' . $el_class;
	} else {
		$layout_return = '' . $el_class;
	}
	return $layout_return;
}
function circle_portfolio_layout_column_before( $layout ) {
	switch ( $layout ) {
		case 'circle';
			$layout = '<div class="bx-gallery__container clearfix" data-init="isotope" data-imgloaded="imagesLoaded"  data-cols="6" data-gap="30">';
			$layout .= '<div class="grid-sizer"></div>';
			print ( $layout ); // WPCS XSS OK.
			break;

		case 'grid';
			$layout = '<div class="bx-gallery__container clearfix" data-init="isotope" data-imgloaded="imagesLoaded"  data-cols="6" data-gap="30">';
			$layout .= '<div class="grid-sizer"></div>';
			print ( $layout ); // WPCS XSS OK.
			break;

		case 'rectangle';
			$layout = '<div>';
			print ( $layout ); // WPCS XSS OK.
			break;

		case 'masonry';
			$layout = '<div class="bx-gallery__container clearfix" data-init="isotope" data-imgloaded="imagesLoaded" data-cols="5" data-gap="30">';
			$layout .= '<div class="grid-sizer"></div>';
			print ( $layout ); // WPCS XSS OK.
			break;

		case 'fullwidth';
			$layout = '<div class="bx-gallery__container clearfix" data-init="isotope" data-imgloaded="imagesLoaded"  data-cols="4" data-gap="0">';
			$layout .= '<div class="grid-sizer"></div>';
			print ( $layout ); // WPCS XSS OK.
			break;
	}
}

function circle_portfolio_layout_column_after() {
	echo '</div>';
}
function circle_service_list( $string ) {
	$array_list = explode( '|', $string );
	echo '<ul>';
	foreach ( $array_list as $li ) {
		echo '<li>' . esc_html( trim( $li ) ) . '</li>';
	}
	echo '</ul>';
}
