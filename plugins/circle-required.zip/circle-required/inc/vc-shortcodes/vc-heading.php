<?php
/**
 * SC Heading Visual Composer Shortcode Builder.
 *
 * @package Circle
 */

/**
 * Register heading content elemnt
 */
function vcmap_circle_heading() {
	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'title',
		'heading'     => esc_html__( 'Title', 'circle' ),
		'admin_label' => true,
	);

	$params[] = array(
		'type'        => 'dropdown',
		'param_name'  => 'title_position',
		'heading'     => esc_html__( 'Title text align', 'circle' ),
		'value'       => array(
			esc_html__( 'Right', 'circle' )  => 'right',
			esc_html__( 'Left', 'circle' )   => 'left',
			esc_html__( 'Center', 'circle' ) => 'center',
		),
		'std'         => 'left',
	);

	$params[] = array(
		'type'        => 'textarea',
		'param_name'  => 'subtitle',
		'heading'     => esc_html__( 'Subtitle', 'circle' ),
		'admin_label' => true,
	);

	$params[] = array(
		'type'        => 'dropdown',
		'param_name'  => 'subtitle_position',
		'heading'     => esc_html__( 'Subtitle text align', 'circle' ),
		'value'       => array(
			esc_html__( 'Right', 'circle' )  => 'right',
			esc_html__( 'Left', 'circle' )   => 'left',
			esc_html__( 'Center', 'circle' ) => 'center',
		),
		'std'         => 'left',
	);

	$params[] = array(
		'type'         => 'checkbox',
		'param_name'   => 'white_mode',
		'heading'      => esc_html__( 'Enable text white mode', 'circle' ),
		'value'        => true,
	);

	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'el_class',
		'heading'     => esc_html__( 'Extra class name', 'circle' ),
	);

	$params[] = array(
		'type'        => 'css_editor',
		'param_name'  => 'css',
		'heading'     => esc_html__( 'CSS box', 'circle' ),
		'group'       => esc_html__( 'Design Options', 'circle' ),
	);

	return array(
		'name'        => esc_html__( 'Heading', 'circle' ),
		'category'    => esc_html__( 'AweThemes', 'circle' ),
		'description' => esc_html__( 'Display your heading', 'circle' ),
		'icon'        => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'params'      => $params,
	);
}
vc_lean_map( 'circle_heading', 'vcmap_circle_heading' );

/**
 * WPBakeryShortCode_Circle_heading
 */
class WPBakeryShortCode_Circle_Heading extends Circle_Shortcode_Abstract {
}
