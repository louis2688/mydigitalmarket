<?php
/**
 * Register icon box content elemnt
 */
function vcmap_circle_icon_box() {
	$params[] = array(
		'type'         => 'checkbox',
		'param_name'   => 'animation',
		'heading'      => esc_html__( 'Hover animation style', 'circle' ),
		'value'        => true,
	);

	$params[] = array(
		'type'        => 'dropdown',
		'param_name'  => 'size',
		'heading'     => esc_html__( 'Size style', 'circle' ),
		'dependency'  => array(
			'element'   => 'animation',
			'value'     => 'true',
		),
		'value'       => array(
			esc_html( 'Large style', 'circle' ) => 'large',
			esc_html( 'Small style', 'circle' ) => 'small',
		),
		'std'         => 'large',
	);

	$params[] = array(
		'type'        => 'attach_image',
		'param_name'  => 'cs_image',
		'heading'     => esc_html__( 'Circle Image', 'circle' ),
		'value'       => '',
		'dependency'  => array(
			'element'  => 'animation',
			'value'    => 'true',
		),
	);
	$params[] = array(
		'type'       => 'dropdown',
		'param_name' => 'type',
		'heading'    => esc_html__( 'Icon Type', 'circle' ),
		'value'      => array(
			esc_html__( 'Icon Font', 'circle' ) => 'icon',
			esc_html__( 'Icon Image', 'circle' ) => 'image',
		),
	);
	$params[] = array(
		'type'        => 'attach_image',
		'param_name'  => 'image',
		'heading'     => esc_html__( 'Image', 'circle' ),
		'value'       => '',
		'dependency'  => array(
			'element'  => 'type',
			'value'    => 'image',
		),
	);
	$params[] = array(
		'type'       => 'dropdown',
		'heading'    => esc_html__( 'Icon library', 'circle' ),
		'dependency' => array(
			'element'  => 'type',
			'value'    => 'icon',
		),
		'value' => array(
			esc_html__( 'Font Awesome', 'circle' )  => 'fontawesome',
			esc_html__( 'Open Iconic', 'circle' )   => 'openiconic',
			esc_html__( 'Typicons', 'circle' )      => 'typicons',
			esc_html__( 'Entypo', 'circle' )        => 'entypo',
			esc_html__( 'Linecons', 'circle' )      => 'linecons',
			esc_html__( 'Mono Social', 'circle' )   => 'monosocial',
			esc_html__( 'Simple Line', 'circle' )   => 'simpleline',
			esc_html__( 'Circle Studio', 'circle' ) => 'circle',
		),
		'admin_label' => true,
		'std'         => 'circle',
		'param_name'  => 'icon_type',
		'description' => esc_html__( 'Select icon library.', 'circle' ),
	);
	$params[] = array(
		'type'          => 'iconpicker',
		'heading'       => esc_html__( 'Icon', 'circle' ),
		'param_name'    => 'icon_fontawesome',
		'value'         => 'fa fa-adjust',
		'settings'      => array(
			'iconsPerPage' => 4000,
		),
		'dependency'   => array(
			'emptyIcon'  => true,
			'element'    => 'icon_type',
			'value'      => 'fontawesome',
		),
		'description' => esc_html__( 'Select icon from library.', 'circle' ),
	);
	$params[] = array(
		'type'       => 'iconpicker',
		'heading'    => esc_html__( 'Icon', 'circle' ),
		'param_name' => 'icon_openiconic',
		'value'      => 'vc-oi vc-oi-dial',
		'settings'   => array(
			'type'         => 'openiconic',
			'iconsPerPage' => 4000,
		),
		'dependency'   => array(
			'emptyIcon'  => true,
			'element'    => 'icon_type',
			'value'      => 'openiconic',
		),
		'description'  => esc_html__( 'Select icon from library.', 'circle' ),
	);
	$params[] = array(
		'type'       => 'iconpicker',
		'heading'    => esc_html__( 'Icon', 'circle' ),
		'param_name' => 'icon_typicons',
		'value'      => 'typcn typcn-adjust-brightness',
		'settings'   => array(
			'type'          => 'typicons',
			'iconsPerPage'  => 4000,
		),
		'dependency'  => array(
			'emptyIcon'   => true,
			'element'     => 'icon_type',
			'value'       => 'typicons',
		),
		'description'   => esc_html__( 'Select icon from library.', 'circle' ),
	);
	$params[] = array(
		'type'        => 'iconpicker',
		'heading'     => esc_html__( 'Icon', 'circle' ),
		'param_name'  => 'icon_entypo',
		'value'       => 'entypo-icon entypo-icon-note',
		'settings'    => array(
			'type'          => 'entypo',
			'iconsPerPage'  => 4000,
		),
		'dependency'  => array(
			'emptyIcon'   => true,
			'element'     => 'icon_type',
			'value'       => 'entypo',
		),
	);
	$params[] = array(
		'type'        => 'iconpicker',
		'heading'     => esc_html__( 'Icon', 'circle' ),
		'param_name'  => 'icon_linecons',
		'value'       => 'vc_li vc_li-heart',
		'settings'    => array(
			'emptyIcon'    => true,
			'type'         => 'linecons',
			'iconsPerPage' => 4000,
		),
		'dependency'  => array(
			'element'     => 'icon_type',
			'value'       => 'linecons',
		),
		'description' => esc_html__( 'Select icon from library.', 'circle' ),
	);
	$params[] = array(
		'type'        => 'iconpicker',
		'heading'     => esc_html__( 'Icon', 'circle' ),
		'param_name'  => 'icon_monosocial',
		'value'       => 'vc-mono vc-mono-fivehundredpx',
		'settings'    => array(
			'emptyIcon'    => true,
			'type'         => 'monosocial',
			'iconsPerPage' => 4000,
		),
		'dependency'  => array(
			'element'   => 'icon_type',
			'value'     => 'monosocial',
		),
		'description' => esc_html__( 'Select icon from library.', 'circle' ),
	);
	$params[] = array(
		'type'         => 'iconpicker',
		'heading'      => __( 'Icon', 'js_composer' ),
		'param_name'   => 'icon_simpleline',
		'value'        => 'icon-diamond',
		'settings'     => array(
			'emptyIcon'    => false,
			'iconsPerPage' => 4000,
			'type'         => 'simpleline',
		),
		'dependency'   => array(
			'element'    => 'icon_type',
			'value'      => 'simpleline',
		),
		'description'  => __( 'Select icon from library.', 'js_composer' ),
	);
	$params[] = array(
		'type'        => 'iconpicker',
		'heading'     => esc_html__( 'Icon', 'circle' ),
		'param_name'  => 'icon_circle',
		'value'       => 'cs cs-water',
		'settings'    => array(
			'emptyIcon'    => true,
			'type'         => 'circle',
			'iconsPerPage' => 4000,
		),
		'dependency'  => array(
			'element'   => 'icon_type',
			'value'     => 'circle',
		),
		'description' => esc_html__( 'Select icon from library.', 'circle' ),
	);

	$params[] = array(
		'type'        => 'dropdown',
		'param_name'  => 'icon_contact',
		'heading'     => esc_html__( 'Icon size', 'circle' ),
		'value'       => array(
			esc_html( 'Large style', 'circle' ) => 'large',
			esc_html( 'Normal style', 'circle' ) => 'normal',
		),
		'dependency'  => array(
			'element'   => 'type',
			'value'     => 'icon',
		),
		'std'        => 'normal',
	);

	$params[] = array(
		'type'        => 'colorpicker',
		'param_name'  => 'icon_color',
		'heading'     => esc_html__( 'Icon color', 'circle' ),
		'value'       => '#fff',
		'dependency'  => array(
			'element'   => 'type',
			'value'     => 'icon',
		),
	);

	$params[] = array(
		'type'       => 'textfield',
		'param_name' => 'title',
		'heading'    => esc_html__( 'Title', 'circle' ),
		'value'      => '',
	);

	$params[] = array(
		'type'       => 'textfield',
		'param_name' => 'link',
		'heading'    => esc_html__( 'Link', 'circle' ),
		'dependency'  => array(
			'element'  => 'animation',
			'value'    => 'true',
		),

	);

	$params[] = array(
		'type'         => 'checkbox',
		'param_name'   => 'white_mode',
		'heading'      => esc_html__( 'Enable text white mode', 'circle' ),
		'value'        => true,
	);

	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'el_class',
		'heading'     => esc_html__( 'Extra class name', 'circle' ),
	);

	$params[] = array(
		'type'        => 'css_editor',
		'param_name'  => 'css',
		'heading'     => esc_html__( 'CSS box', 'circle' ),
		'group'       => esc_html__( 'Design Options', 'circle' ),
	);

	return array(
		'name'     => esc_html__( 'Icon box', 'circle' ),
		'icon'     => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'category' => esc_html__( 'AweThemes', 'circle' ),
		'params'   => $params,
		'js_view'  => 'VcIconElementView_Backend',
	);
}
vc_lean_map( 'circle_icon', 'vcmap_circle_icon_box' );

/**
 * Icon-form content element extends Circle_Shortcode_Abstract class
 */
class WPBakeryShortCode_Circle_Icon extends Circle_Shortcode_Abstract {

}


