<?php
/**
 * Plugin Name: Circle Required
 * Description: Circle plugin for Circle Theme.
 * Plugin URI: https://awethemes.com/
 * Version: 1.0.0
 * Author: awethemes
 * Author URI: https://awethemes.com
 *
 * @package Circle
 * @subpackage Circle Required
 */

define( 'CIRCLE_PLUGIN_PATH', plugin_dir_path( __FILE__ ) );
define( 'CIRCLE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

class Circle_Required_Loader {

	public function init() {
		require_once CIRCLE_PLUGIN_PATH . '/vendor/autoload.php';

		require_once CIRCLE_PLUGIN_PATH . 'inc/functions.php';

		require CIRCLE_PLUGIN_PATH . 'inc/breadcrumbs.php';

		// Autoload Visual Composer.
		add_action( 'vc_after_init', array( $this, 'autoload_vc' ), 20 );

		// Register Custom Post Types.
		$this->register_cpt();

		// Register Custom Taxonomies.
		$this->register_custom_taxonomies();

		// Register portfolio meta box.
		add_filter( 'circle_header_custom_post_type_support', array( $this, 'portfolio_custom_header' ) );

		// Manage template loading.
		add_filter( 'template_include', array( $this, 'manage_template' ) );

		add_filter( 'circle_get_sidebar_setting', array( $this, 'sidebar_setting' ) );

		add_action( 'circle_navs_portfolios', array( $this, 'portfolio_navs' ) );

		add_filter( 'circle_page_title_post_type_support', array( $this, 'portfolio_page_title' ) );

		add_action( 'after_setup_theme', array( $this, 'add_portfolio_thumbnail_sizes' ) );

		add_action( 'after_setup_theme', array( $this, 'add_sc_post_thumbnail_size' ) );
	}

	public function autoload_vc() {
		if ( ! class_exists( 'WPBakeryShortCode_Extended' ) ) {
			// Required vc-extended package.
			return;
		}

		require_once CIRCLE_PLUGIN_PATH . '/inc/class-circle-shortcode-abstract.php';

		$paths = glob( CIRCLE_PLUGIN_PATH . '/inc/vc-shortcodes/vc-*.php' );

		foreach ( $paths as $path ) {
			require_once $path;
		}
	}

	public function register_cpt() {

		register_via_cpt_core(
			array( esc_html__( 'Portfolio', 'circle' ), esc_html__( 'Portfolios', 'circle' ), 'at_portfolio' ),
			array(
				'hierarchical'        => false,
				'exclude_from_search' => true,
				'publicly_queryable'  => true,
				'show_in_nav_menus'   => true,
				'show_in_admin_bar'   => true,
				'menu_icon'           => false,
				'supports'            => array( 'title', 'editor', 'thumbnail' ),
				'has_archive'         => false,
				'rewrite'             => array( 'slug' => 'portfolio' ),
			)
		);
	}

	public function register_custom_taxonomies() {
		register_via_taxonomy_core(
			array(
				__( 'Portfolio category', 'circle' ),
				__( 'Portfolio categories', 'circle' ),
				'at_portfolio_cat',
			),
			array(),
			array( 'at_portfolio' )
		);
	}

	public function portfolio_custom_header( $meta_box ) {
		$meta_box[] = 'at_portfolio';
		return $meta_box;
	}

	public function portfolio_navs() {
		?>
		<div class="single-pager white clearfix">
			<div class="single-pager__vline">
				<span class="single-pager__icon black icon-layers"></span>
			</div>
			<?php
			// Prev portfolio.
			if ( $prev_post = get_previous_post() ) {
				$prev_title = strip_tags( str_replace( '"', '', $prev_post->post_title ) );
				ob_start();
				?>
				<div class="single-pager__item single-pager__item--prev pull-right">
					<a href="<?php the_permalink( $prev_post->ID ); ?>" class="clearfix" title="">
						<div class="pull-left">
							<p class="single-pager__button single-pager__button--prev text-uppercase">Preview</p>
							<p class="single-pager__name"><?php echo esc_html( $prev_title ) ?></p>
						</div>
					</a>
				</div>
				<?php
				$prev = ob_get_clean();
				print ( $prev ); // WPCS XSS OK.
			}
			// Next portfolio.
			if ( $next_post = get_next_post() ) {
				$next_title = strip_tags( str_replace( '"', '', $next_post->post_title ) );
				ob_start();
				?>
				<div class="single-pager__item single-pager__item--next pull-left">
					<a href="<?php the_permalink( $next_post->ID ); ?>" class="clearfix" title="">
						<div class="pull-right">
							<p class="single-pager__button single-pager__button--next text-uppercase">Next</p>
							<p class="single-pager__name"><?php echo esc_html( $next_title ) ?></p>
						</div>
					</a>
				</div>
				<?php
				$next = ob_get_clean();
				print ( $next ); // WPCS XSS OK.
			}
			?>
		</div>
		<?php
	}

	public function manage_template( $template ) {
		if ( is_singular( 'at_portfolio' ) ) {
			if ( ! locate_template( 'single-at_portfolio.php' ) ) {
				$template = CIRCLE_PLUGIN_PATH . 'inc/templates/single-at_portfolio.php';
			}
		}

		return $template;
	}


	public function sidebar_setting( $setting ) {
		if ( is_singular( 'at_portfolio' ) ) {
			$setting = 'none';
		}

		return $setting;
	}

	public function portfolio_page_title( $post_types ) {
		$post_types[] = 'at_portfolio';

		return $post_types;
	}



	public function add_portfolio_thumbnail_sizes() {
		add_image_size( 'at-portfolio-rectangle', 850, 550, true );
		add_image_size( 'at-portfolio-circle', 500, 500, true );
	}

	public function add_sc_post_thumbnail_size() {
		add_image_size( 'sc-post-thumbnail', 700, 700, true );
	}
}
add_action( 'plugins_loaded', array( new Circle_Required_Loader, 'init' ) );

/**
 * //
 *
 * @param  array $atts
 * @return string
 */
function circle_shortcode_logo( $atts ) {
	$atts = shortcode_atts( array(
		'link' => true,
		'logo' => 'site_logo',
	), $atts );

	return circle_site_logo( $atts['logo'], false, $atts['link'] );
}
add_shortcode( 'circle_logo', 'circle_shortcode_logo' );

/**
 * //
 *
 * @return string
 */
function circle_shortcode_copyright() {
	return circle_site_copyright( '<p class="site-copyright">', '</p>', false );
}
add_shortcode( 'circle_copyright', 'circle_shortcode_copyright' );

/**
 * Register metabox and term-metabox for blog header.
 *
 * @param  ATFW $atfw ATFW Instance.
 */
function circle_register_custom_page_title_metabox( $atfw ) {
	$fields = array(
		array(
			'id'      => 'page_title_custom',
			'type'    => 'text',
			'label'   => esc_html__( 'Display page title customizer', 'circle' ),
			'desc'	  => esc_html__( 'Tips: Use "|" to generate a "</br>" tag.', 'circle' ),
		),
	);

	// Register metabox.
	$atfw->register_metabox( new ATFW_Metabox( 'circle-page-title', array(
		'title'   => esc_html__( 'Page Title customizer', 'circle' ),
		'screen'  => apply_filters( 'circle_page_title_post_type_support', array( 'post', 'page' ) ),
		'fields'  => $fields,
		'context' => 'side',
	) ) );

	// Register term-metabox.
	$atfw->register_term_metabox( array(
		'id'       => 'circle-page-title',
		'title'    => esc_html__( 'Page Title customizer', 'circle' ),
		'taxonomy' => apply_filters( 'circle_page_title_taxonomy_support', array( 'category', 'post_tag' ) ),
		'fields'   => $fields,
	) );
}
add_action( 'atfw_init', 'circle_register_custom_page_title_metabox' );
