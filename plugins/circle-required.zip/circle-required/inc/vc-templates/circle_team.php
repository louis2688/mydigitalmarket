<?php
/**
 * Template Team member templates shortcode
 *
 * @package Circle
 */

$atts['_slick_breakpoints'] = isset( $atts['_slick_breakpoints'] ) ? $atts['_slick_breakpoints'] : 'lg:3|md:3|sm:2|xs:1';
$slick_atts = Extras_Composer_Utils::parse_slick_atts( $atts );

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

// Build member group fields.
$members = (array) vc_param_group_parse_atts( $atts['members'] );
$members = array_map( function ( $member ) {
	return shortcode_atts( array(
		'avatar'          => '',
		'name'            => '',
		'position'        => '',
	), $member );
}, $members );
// Check valid $member.
if ( empty( $members ) ) {
	return;
}

// Build class
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );
?>
<div class="blogs <?php echo esc_attr( $el_class ); ?>" data-fade="false" <?php print $this->build_attributes( $slick_atts ); // WPCS: xss ok. ?>>
	<?php foreach ( $members as $member ) : ?>
		<?php if ( ! wp_get_attachment_image_src( $member['avatar'] ) ) {continue;}  ?>
		<div class="pl-0 pr-0">
			<div class="blogs__item">
				<div class="blogs__img">
					<span><?php echo wp_get_attachment_image( $member['avatar'], 'full' ); ?></span>
				</div>
				<?php if ( trim( $member['name'] ) ) : ?>
					<div class="blogs__info">
						<div class="blogs__name">
							<h2 class="mb-0"><span><?php echo esc_html( trim( $member['name'] ) ) ?></span></h2>
							<?php if ( trim( $member['position'] ) ) : ?>
								<span class="blogs__meta text-uppercase"><?php echo esc_html( $member['position'] ) ?></span>
							<?php endif ?>
						</div>
					</div>
				<?php endif ?>
			</div><!-- /.blogs__item -->
		</div>
	<?php endforeach; ?>
</div>
