<?php

/**
 * Circle Page title Visual Composer Shortcode Builder
 */
function vcmap_circle_pagetitle() {

	$params[] = array(
		'type'        => 'dropdown',
		'param_name'  => 'size',
		'heading'     => esc_html__( 'Size', 'circle' ),
		'std'           => 'normal',
		'value'         => array(
			esc_html__( 'Normal', 'circle' ) => 'normal',
			esc_html__( 'Small', 'circle' ) => 'small',
		),
	);

	$params[] = array(
		'type'         => 'checkbox',
		'param_name'   => 'white_mode',
		'heading'      => esc_html__( 'Enable white mode?', 'circle' ),
		'value'		   => array( __( 'Yes', 'circle' ) => 'yes' ),
	);

	$params[] = array(
		'type'         => 'checkbox',
		'param_name'   => 'underline',
		'heading'      => esc_html__( 'Enable underline?', 'circle' ),
		'value'		   => array( __( 'Yes', 'circle' ) => 'yes' ),
	);

	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'el_class',
		'heading'     => esc_html__( 'Extra class name', 'circle' ),
	);

	$params[] = array(
		'type'        => 'css_editor',
		'param_name'  => 'css',
		'heading'     => esc_html__( 'CSS box', 'circle' ),
		'group'       => esc_html__( 'Design Options', 'circle' ),
	);

	return array(
		'name'        => esc_html__( 'Page Title', 'circle' ),
		'description' => esc_html__( 'Display a customizer page title', 'circle' ),
		'category'    => esc_html__( 'AweThemes', 'circle' ),
		'icon'        => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'params'      => $params,
	);
}
vc_lean_map( 'circle_pagetitle', 'vcmap_circle_pagetitle' );

class WPBakeryShortCode_Circle_Pagetitle extends Circle_Shortcode_Abstract {
	//
}
