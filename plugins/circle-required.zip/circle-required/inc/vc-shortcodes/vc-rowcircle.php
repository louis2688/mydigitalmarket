<?php
/**
 * Circle Row Circle Visual Composer Shortcode Builder
 */
function vcmap_circle_rowcircle() {

	$params[] = array(
		'type'        => 'dropdown',
		'param_name'  => 'circle_style',
		'heading'     => esc_html__( 'Style', 'circle' ),
		'group'       => esc_html__( 'Circles', 'circle' ),
		'std'           => 'normal',
		'value'         => array(
			esc_html__( 'Normal', 'circle' ) => 'normal',
			esc_html__( 'Parallax', 'circle' ) => 'parallax',
		),
	);

	$params[] = array(
		'type'        => 'param_group',
		'param_name'  => 'circles',
		'heading'     => esc_html__( 'Circles', 'circle' ),
		'group'       => esc_html__( 'Circles', 'circle' ),
		'params'      => array(
			array(
				'type'          => 'dropdown',
				'param_name'    => 'circle_position',
				'heading'       => esc_html__( 'Circle position', 'circle' ),
				'std'           => 'aside',
				'value'         => array(
					esc_html__( 'Aside', 'circle' ) 		=> 'aside',
					esc_html__( 'Center box', 'circle' ) 	=> 'center_box',
				),
				'description' => esc_html__( 'Note: For `Parallax` style, the Center box won\'t show by default design', 'circle' ),
			),
			array(
				'type'          => 'dropdown',
				'param_name'    => 'position_vertical',
				'heading'       => esc_html__( 'Position vertical', 'circle' ),
				'std'           => 'top',
				'value'         => array(
					esc_html__( 'Top', 'circle' ) 		=> 'top',
					esc_html__( 'Bottom', 'circle' ) 	=> 'bottom',
				),
				'dependency'  => array(
					'element'  => 'circle_position',
					'value'    => 'aside',
				),
			),
			array(
				'type'          => 'dropdown',
				'param_name'    => 'position_horizontal',
				'heading'       => esc_html__( 'Position horizontal', 'circle' ),
				'std'           => 'left',
				'value'         => array(
					esc_html__( 'Left', 'circle' ) 		=> 'left',
					esc_html__( 'Right', 'circle' ) 	=> 'right',
				),
				'dependency'  => array(
					'element'  => 'circle_position',
					'value'    => 'aside',
				),
			),
			array(
				'type'        => 'attach_image',
				'param_name'  => 'circle_image',
				'heading'     => esc_html__( 'Circle Image', 'circle' ),
				'admin_label' => true,
			),
		),
	);

	$params[] = array(
		'type'        => 'attach_image',
		'param_name'  => 'banner_image',
		'heading'     => esc_html__( 'Banner Image', 'circle' ),
		'group'       => esc_html__( 'Banner Image', 'circle' ),
	);

	$params[] = array(
		'type'        => 'dropdown',
		'param_name'  => 'title_position',
		'heading'     => esc_html__( 'Position', 'circle' ),
		'group'       => esc_html__( 'Row title', 'circle' ),
		'std'           => 'left',
		'value'         => array(
			esc_html__( 'Left', 'circle' ) => 'left',
			esc_html__( 'Right', 'circle' ) => 'right',
		),
	);

	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'title',
		'heading'     => esc_html__( 'Title', 'circle' ),
		'group'       => esc_html__( 'Row title', 'circle' ),
	);

	$params[] = array(
		'type'         => 'checkbox',
		'param_name'   => 'white',
		'heading'      => esc_html__( 'Enable white text mode?', 'circle' ),
		'group'       => esc_html__( 'Row title', 'circle' ),
		'value'		   => array( __( 'Yes', 'circle' ) => 'yes' ),
	);

	vc_add_params( 'vc_row', $params );
}
add_action( 'admin_init', 'vcmap_circle_rowcircle' );

function _vc_row_hook( $output, $shortcode, $atts ) {
	if ( 'vc_row' !== $shortcode->getShortcode() ) {
		return $output;
	}

	$before = '';
	$content = apply_filters( 'after_open_vc_row', $before, $output, $shortcode, $atts );

	return preg_replace( '/(<div[^>]+class="[^"]*vc_row\s[^>]*>)/', "$1\n{$content}\n", $output );
}
add_filter( 'vc_shortcode_output', '_vc_row_hook', 10, 3 );

function vcmap_circle_rowcircle_template( $before, $output, $shortcode, $atts ) {

	$atts = shortcode_atts( array(
		'circle_style'   => 'normal',
		'circles'   	 => '',
		'banner_image' 	 => '',
		'title_position' => 'left',
		'title'			 => '',
		'white'			 => '',
	), $atts );

	// Build brands group fields.
	$circles = (array) vc_param_group_parse_atts( $atts['circles'] );

	$circles = array_map( function ( $circle ) {
		return shortcode_atts( array(
			'circle_position'		=> 'aside',
			'position_vertical'		=> 'top',
			'position_horizontal'	=> 'left',
			'circle_image'			=> '',
		), $circle );
	}, $circles );

	ob_start();
	?>
	<?php if ( count( $circles ) >= 1 && $circles[0]['circle_image'] ) : ?>
		<?php if ( 'normal' != $atts['circle_style'] ) : ?>
			<?php foreach ( $circles as $circle ) : ?>
			<?php $circle_url = wp_get_attachment_image_url( $circle['circle_image'], 'full' );?>

			<div class="cricle parallax-item parallax-<?php echo esc_html( $circle['position_vertical'] );?> parallax-<?php echo esc_html( $circle['position_horizontal'] );?>" data-init="parallax" data-parallax-image="<?php print $circle_url; // Wpcs :xss ok.?>" data-speed="5">
	    	</div><!-- /.cricle -->
	    	<?php endforeach; ?>
		<?php else : ?>
			<div class="cricle">
			<?php foreach ( $circles as $circle ) : ?>
				<?php if ( $circle['circle_image'] ) : ?>
				<?php
				$circle_class = '';
				if ( 'aside' != $circle['circle_position'] ) {
					$circle_class = 'cricle__item--center-box';
				} else {
					$circle_class = 'cricle__item--'. $circle['position_vertical'];
					$circle_class .= ' cricle__item--'. $circle['position_horizontal'];
				}
				?>
				<span class="cricle__item <?php echo esc_html( $circle_class );?>" data-waypoint="waypointEffect">
					<?php echo wp_get_attachment_image( $circle['circle_image'], 'full' ); ?>
				</span>
				<?php endif;?>
			<?php endforeach; ?>
			</div><!-- /.cricle -->
		<?php endif;?>
	<?php endif;?>
	<?php if ( $atts['banner_image'] ) : ?>
	<div class="page-title__people">
		<?php echo wp_get_attachment_image( $atts['banner_image'], 'full' ); ?>
	</div><!-- /.page-title__people -->
	<?php endif;?>
	<?php if ( $atts['title'] ) : ?>
	<div class="vertical-site">
		<span class="<?php if ( 'yes' == $atts['white'] ) : ?>white<?php endif;?> vertical-site__item text-uppercase vertical-site__item--bottom vertical-site__item--<?php echo esc_html( $atts['title_position'] );?>" data-waypoint="waypointEffect">
			<?php echo esc_html( $atts['title'] );?>
		</span>
	</div><!-- /.vertical-site -->
	<?php endif;?>
	<?php
	return ob_get_clean();
}
add_filter( 'after_open_vc_row', 'vcmap_circle_rowcircle_template', 10, 4 );
