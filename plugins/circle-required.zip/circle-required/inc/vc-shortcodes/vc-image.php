<?php
/**
 * Circle Image Visual Composer Shortcode Builder
 *
 * @package Circle
 */

function vcmap_circle_image() {
	$params[] = array(
		'type'          => 'attach_image',
		'param_name'    => 'image',
		'heading'       => esc_html__( 'Image Circle', 'circle' ),
		'description'   => 'Insert Image Circle.',
	);

	$params[] = array(
		'type'          => 'dropdown',
		'param_name'    => 'type',
		'heading'       => esc_html__( 'Circle type', 'circle' ),
		'value'         => array(
			esc_html__( 'Aqua', 'circle' )     => '11',
			esc_html__( 'Hot Pink', 'circle' ) => '12',
			esc_html__( 'Custom', 'circle' )   => '0',
		),
		'std'           => '11',
		'description'   => esc_html__( 'Default: Aqua', 'circle' ),
	);

	$params[] = array(
		'type'          => 'attach_image',
		'param_name'    => 'circle_image',
		'heading'       => esc_html__( 'Circle background', 'circle' ),
		'dependency'    => array(
			'element'     => 'type',
			'value'       => '0',
		),
	);

	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'el_class',
		'heading'     => esc_html__( 'Extra class name', 'circle' ),
	);

	$params[] = array(
		'type'        => 'css_editor',
		'param_name'  => 'css',
		'heading'     => esc_html__( 'CSS box', 'circle' ),
		'group'       => esc_html__( 'Design Options', 'circle' ),
	);
	return array(
		'name'        => esc_html__( 'Image Circle', 'circle' ),
		'icon'        => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'category'    => esc_html__( 'AweThemes', 'circle' ),
		'description' => esc_html__( 'Display image', 'circle' ),
		'params'      => $params,
	);
}
vc_lean_map( 'circle_image', 'vcmap_circle_image' );

/**
 * WPBakeryShortCode_VC_Circle_Image class.
 */
class WPBakeryShortCode_Circle_Image extends Circle_Shortcode_Abstract {
}
