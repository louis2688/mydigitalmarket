<?php
function vc_circle_get_portfolio_categories() {
	$autocomplete_value = array();
	$terms = get_terms( 'at_portfolio_cat' );

	if ( empty( $terms ) ) {
		return $autocomplete_value;
	}

	foreach ( $terms as $term ) {
		$autocomplete_value[] = array(
			'label' => $term->name,
			'value' => $term->term_id,
		);
	}

	return $autocomplete_value;
}

function vc_circle_portfolios() {
	$order_by_values = array(
		__( 'Date', 'circle' )          => 'date',
		__( 'ID', 'circle' )            => 'ID',
		__( 'Author', 'circle' )        => 'author',
		__( 'Title', 'circle' )         => 'title',
		__( 'Modified', 'circle' )      => 'modified',
		__( 'Random', 'circle' )        => 'rand',
		__( 'Comment count', 'circle' ) => 'comment_count',
		__( 'Menu order', 'circle' )    => 'menu_order',
	);

	$order_way_values = array(
		__( 'Descending', 'circle' ) => 'DESC',
		__( 'Ascending', 'circle' )  => 'ASC',
	);

	$params[] = array(
		'type'        => 'dropdown',
		'param_name'  => 'layout',
		'heading'     => __( 'Style', 'circle' ),
		'value'       => array(
			__( 'Portfolio Circle', 'circle' )      => 'circle',
			__( 'Portfolio Grid', 'circle' )        => 'grid',
			__( 'Portfolio Rectangle', 'circle' )   => 'rectangle',
			__( 'Portfolio Masonry', 'circle' )     => 'masonry',
			__( 'Portfolio Fullwidth', 'circle' )   => 'fullwidth',
		),
		'std'         => 'circle',
		'description' => 'Default: Portfolio Circle',
		'admin_label' => true,
	);

	$params[] = array(
		'type'        => 'autocomplete',
		'param_name'  => 'filter_ids',
		'heading'     => __( 'Choose categories', 'circle' ),
		'settings'    => array(
			'multiple'       => 1,
			'sortable'       => 1,
			'min_length'     => 1,
			'unique_values'  => true,
			'display_inline' => true,
			'values'         => vc_circle_get_portfolio_categories(),
		),
		'description' => 'Default: Auto select',
	);

	$params[] = array(
		'type'       => 'dropdown',
		'param_name' => 'show_filter',
		'heading'    => __( 'Display filter', 'circle' ),
		'value'      => array(
			__( 'Yes', 'circle' ) => 'yes',
			__( 'No', 'circle' )  => 'no',
		),
		'std'        => 'no',
		'dependency' => array(
			'element'            => 'layout',
			'value_not_equal_to' => 'rectangle',
		),
	);

	$params[] = array(
		'type'        => 'dropdown',
		'heading'     => __( 'Order by', 'brilliant' ),
		'param_name'  => 'orderby',
		'value'       => $order_by_values,
		'description' => sprintf( __( 'Select how to sort retrieved products. More at %s.', 'brilliant' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
		'std'         => 'date',
	);

	$params[] = array(
		'type'        => 'dropdown',
		'heading'     => __( 'Sort order', 'brilliant' ),
		'param_name'  => 'order',
		'value'       => $order_way_values,
		'description' => sprintf( __( 'Designates the ascending or descending order. More at %s.', 'brilliant' ), '<a href="http://codex.wordpress.org/Class_Reference/WP_Query#Order_.26_Orderby_Parameters" target="_blank">WordPress codex page</a>' ),
		'std'         => 'DESC',
	);

	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'number',
		'heading'     => __( 'Number of portfolios', 'circle' ),
		'std'         => 6,
		'description' => 'Default: 6',
	);

	$params[] = array(
		'type'        => 'textfield',
		'param_name'  => 'el_class',
		'heading'     => esc_html__( 'Extra class name', 'circle' ),
	);

	$params[] = array(
		'type'        => 'css_editor',
		'param_name'  => 'css',
		'heading'     => esc_html__( 'CSS box', 'circle' ),
		'group'       => esc_html__( 'Design Options', 'circle' ),
	);

	return array(
		'name'        => esc_html__( 'Portfolios', 'circle' ),
		'icon'        => CIRCLE_PLUGIN_URL . 'icons/awethemes.png',
		'category'    => esc_html__( 'AweThemes', 'circle' ),
		'params'      => $params,
	);
}
vc_lean_map( 'circle_portfolios', 'vc_circle_portfolios' );

class WPBakeryShortCode_Circle_Portfolios extends Circle_Shortcode_Abstract {

}
