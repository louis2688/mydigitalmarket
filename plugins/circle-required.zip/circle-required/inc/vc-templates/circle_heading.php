<?php
/**
 * Template for shortcode circle heading
 *
 * @package Circle
 */

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

if ( ! trim( $atts['title'] ) && ! trim( $atts['subtitle'] ) ) {
	return;
}

// Set position for title
$title_css = '';
if ( trim( $atts['title'] ) ) {
	switch ( $atts['title_position'] ) {
		case 'right':
			$title_css = 'bx-content__title--line-right text-right';
			break;

		case 'center':
			$title_css = 'text-center';
			break;

		default :
			$title_css = 'bx-content__title--line-left';
			break;
	}
}

// Set position for subtitle
$subtitle_css = '';
if ( trim( $atts['subtitle'] ) ) {

	switch ( $atts['subtitle_position'] ) {
		case 'right':
			$subtitle_css = 'text-right';
			break;

		case 'center':
			$subtitle_css = 'text-center';
			break;

		default :
			$subtitle_css = '';
			break;
	}
}

// Build element classes.
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );
$white_mode = $atts['white_mode'] ? ' white':'';
$title_css    .= $white_mode;
$subtitle_css .= $white_mode;
?>

<div class="bx-content__header clearfix <?php echo esc_attr( $el_class ); ?>">
	<?php if ( trim( $atts['title'] ) ) : ?>
		<h2 class="h1 bx-content__title <?php echo esc_attr( $title_css ); ?>" data-waypoint="waypointEffect"><?php echo esc_html( $atts['title'] ); ?></h2>
	<?php endif ?>
	<?php if ( trim( $atts['subtitle'] ) ) : ?>
		<div class="h2 our-history__header <?php echo esc_attr( $subtitle_css ); ?>">
			<?php print( wpautop( $atts['subtitle'] ) ); // WPCS XSS OK. ?>
		</div>
	<?php endif ?>
</div><!-- /.bx-content__header -->
