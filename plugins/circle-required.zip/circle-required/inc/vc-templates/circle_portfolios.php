<?php
/**
 * Template for shortcode circle_portfolios
 *
 * @var array $atts
 */

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

if ( 0 >= ( $atts['number'] ) ) {
	return;
}


$query_agrs = array(
	'post_type'      => 'at_portfolio',
	'posts_per_page' => $atts['number'],
	'orderby'        => $atts['orderby'],
	'order'          => $atts['order'],

);
// Set querry
if ( $atts['filter_ids'] ) {
	$term_id = array_map( 'trim', explode( ',', $atts['filter_ids'] ) );
	$query_agrs['tax_query'] = array(
		array(
			'taxonomy' => 'at_portfolio_cat',
			'field' => 'id',
			'terms' => $term_id,
		),
	);
}

$query = new WP_Query( $query_agrs );

if ( ! $query->have_posts() ) {
	return;
}

// Build element classes.
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );

;
// Display layout
if ( 'rectangle' != $atts['layout'] ) {
	echo '<div class="bx-gallery '. esc_attr( circle_portfolio_layout( $atts['layout'], $el_class ) ) .'" data-init="gallery">';
}

// Display filter
if ( 'yes' === $atts['show_filter'] ) {
	if ( ! $atts['filter_ids'] ) {
		$term_id = array();
		while ( $query->have_posts() ) {
			$query->the_post();
			if ( ! has_post_thumbnail() ) {
				continue;
			}
			$terms = wp_get_post_terms( get_the_ID(), 'at_portfolio_cat' );
			foreach ( $terms as $term ) {
				$term_id[] = $term->term_id;
			}
		}
	}
	$term_id = array_unique( $term_id );

	$this->load_template_part( 'circle_portfolios/filter.php', array( 'ids' => $term_id ) );
}

// Display layout column before
circle_portfolio_layout_column_before( $atts['layout'] );

// Start loop
$i = 0;
while ( $query->have_posts() ) {
	$query->the_post();
	if ( ! has_post_thumbnail() ) {
		continue;
	}
	++$i;
	$pass_args = array(
		'index'  => $i,
		'layout' => $atts['layout'],
	);

	$this->load_template_part( 'circle_portfolios/portfolios-' . $atts['layout'] . '.php', $pass_args );

}
wp_reset_postdata();

// Display layout column after
circle_portfolio_layout_column_after();

// End display layout
if ( 'rectangle' != $atts['layout'] ) {
	echo '</div>';
}
?>
