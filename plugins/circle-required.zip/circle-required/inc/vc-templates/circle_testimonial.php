<?php
/**
 * Template for the circle_testimonial shortcode.
 *
 * @package Circle
 */

if ( 0 == $atts['posts_per_page'] ) {
	return;
}

$query = $this->buildWPQuery( $atts );

if ( ! $query->have_posts() ) {
	return;
}

$atts['_slick_breakpoints'] = isset( $atts['_slick_breakpoints'] ) ? $atts['_slick_breakpoints'] : 'lg:2|md:2|sm:2|xs:1';
$slick_atts = Extras_Composer_Utils::parse_slick_atts( $atts );

$atts = shortcode_atts( array(
	'el_class'   => '',
	'css'        => '',
), $atts );

// Build element classes.
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );

?>

<div class="testimonital__slick <?php echo esc_attr( $el_class ); ?>" data-fade="false" <?php print $this->build_attributes( $slick_atts ); // WPCS: xss ok. ?>>
	<?php while ( $query->have_posts() ) : $query->the_post(); ?>
		<?php if ( ! get_the_content() ) {continue;} ?>
		<?php $metadata = AT_Testimonial_Core::get_the_details( get_the_ID() ); ?>

		<div id="cc-testimonial-<?php echo esc_attr( get_the_ID() ); ?>" class="testimonital__item text-center <?php print $atts['white_mode'] ? 'cc-testimonial--white' : ''; ?>">
			<div class="testimonital__info black mb-60">
				<div class="bx-content__title bx-content__title--line-bottom" data-waypoint="waypointEffect"><?php the_content(); ?></div>
			</div>
			<?php if ( get_the_post_thumbnail() || $metadata['name'] ) : ?>
				<div class="testimonital__media mb-40">
					<?php if ( get_the_post_thumbnail() ) : ?>
						<div class="testimonital__img">
							<?php the_post_thumbnail( 'thumbnail' ); ?>
						</div>
					<?php endif ?>
					<?php if ( $metadata['name'] ) : ?>
						<p class="testimonital__name text-uppercase"><?php echo esc_html( $metadata['name'] ); ?></p>
					<?php endif ?>
				</div>
			<?php endif ?>
		</div><!-- /.testimonital__item -->

	<?php endwhile; ?>
</div>

<?php wp_reset_postdata(); ?>
