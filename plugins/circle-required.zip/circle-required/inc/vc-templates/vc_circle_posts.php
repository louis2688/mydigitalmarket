<?php
/**
 * Template for shortcode circle_posts
 *
 * @package Circle
 */

$atts['_slick_breakpoints'] = isset( $atts['_slick_breakpoints'] ) ? $atts['_slick_breakpoints'] : 'lg:3|md:3|sm:2|xs:1';
$slick_atts = Extras_Composer_Utils::parse_slick_atts( $atts );

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );
$posts_query = $atts['loop'];

list( $args, $my_query ) = vc_build_loop_query( $posts_query, false );

// Build element classes.
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );
?>
<div class="blogs <?php echo esc_attr( $el_class ); ?>" data-fade="false" <?php print $this->build_attributes( $slick_atts ); // WPCS: xss ok. ?>>
	<?php while ( $my_query->have_posts() ) : $my_query->the_post(); ?>
	<div class="col-md-4">
		<div class="blogs__item">
			<?php if ( has_post_thumbnail() ) : ?>
			<div class="blogs__img">
				<a href="<?php echo esc_url( get_permalink() ); ?>">
					<?php the_post_thumbnail( 'sc-post-thumbnail' ); ?>
				</a>
			</div>
			<?php endif;?>
			<div class="blogs__info">
				<div class="blogs__name">
					<?php the_title( '<h2 class="mb-0"><a href="' . esc_url( get_permalink() ) . '">', '</a></h2>' );?>
					<?php circle_posts_carousel_time();?>
				</div>
				<p class="blogs__desc mb-0"><?php echo wp_trim_words( get_the_excerpt(), 35, '...' ); // Wpcs: xss ok.?></p>
			</div>
		</div><!-- /.blogs__item -->
	</div>
	<?php endwhile; ?>
</div>
<?php wp_reset_postdata(); ?>
