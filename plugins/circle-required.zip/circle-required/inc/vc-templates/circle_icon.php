<?php

$atts = vc_map_get_attributes( $this->getShortcode(), $atts );

// Get icon_type
$icon_type = 'icon_' . $atts['icon_type'];

if ( ! $atts['title'] && ! $atts[ $icon_type ] && ! $atts['image'] ) {
	return;
}

// Get html
if ( trim( $atts['link'] ) ) {
	$element_start = '<a href="'. $atts['link'] .'" target="_blank">';
	$element_end = '</a>';
} else {
	$element_start = '<div>';
	$element_end = '</div>';
}

// White mode
$white_mode = $atts['white_mode'] ? ' white':'';

// Fix icon style
$icon_style = $atts['cs_image'] ? '':'icon_fix';
$icon_color = $atts['icon_color'] ? 'style = "color: ' . $atts['icon_color'] . ';"':'';

// Fix size icon box
$item_size = 'small' === $atts['size'] ? 'highlight__item':'services-home__item';
$img_size = 'small' === $atts['size'] ? 'highlight__img':'services-home__img';
$icon_size = 'small' === $atts['size'] ? ' highlight__icon':' services-home__icon';
$name_size = 'small' === $atts['size'] ? 'highlight__name':'services-home__name';

// Set class icon
$icon_class = $icon_style . $icon_size;

// Chang size icon for contact
$icon_contact = '';
if ( 'large' === $atts['icon_contact'] ) {
	$icon_contact = 'style = "font-size: 160px"';
}

// Build class
$el_class  = $this->getExtraClass( $atts['el_class'] );
$el_class .= vc_shortcode_custom_css_class( $atts['css'], ' ' );

// Enqueue needed icon font.
vc_icon_element_fonts_enqueue( $atts['icon_type'] );

?>

<?php if ( $atts['animation'] ) : ?>
<div class="text-center <?php echo esc_attr( $el_class ); ?> <?php echo esc_attr( $item_size ); ?>" data-waypoint="waypointEffect">

	<?php print( $element_start ); // WPCS XSS OK> ?>

		<div class="<?php echo esc_attr( $img_size ); ?>">
			<?php echo wp_get_attachment_image( $atts['cs_image'], 'full' ); ?>

			<?php if ( wp_get_attachment_url( $atts['image'] ) ) : ?>
				<span class="<?php echo esc_attr( $icon_size ); ?>"><?php echo wp_get_attachment_image( $atts['image'], 'full' ); ?></span>
			<?php elseif ( 'icon' === $atts['type'] && $atts[ $icon_type ] ) : ?>
				<span class="<?php echo esc_attr( $icon_class ); ?>" <?php echo ( $icon_contact ); // WPCS XSS OK. ?>><i class="<?php echo esc_attr( $atts[ $icon_type ] ); ?>" <?php echo ( $icon_color ); // WPCS XSS OK. ?>></i></span>
			<?php endif; ?>
		</div>

		<?php if ( trim( $atts['title'] ) ) : ?>
			<h2 class="<?php echo esc_attr( $name_size ); ?> <?php echo esc_attr( $white_mode ); ?>"><?php echo esc_html( trim( $atts['title'] ) ); ?></h2>
		<?php endif ?>

	<?php print( $element_end ); // WPCS XSS OK> ?>

</div>
<?php else : ?>
	<div class="sport-single__item <?php echo esc_attr( $el_class ); ?>">
		<?php if ( wp_get_attachment_url( $atts['image'] ) ) : ?>
			<div class="sport-single_item--center">
		<?php else : ?>
			<div class="text-center">
		<?php endif; ?>

			<?php if ( wp_get_attachment_url( $atts['image'] ) ) : ?>
				<p class="mb-20"><?php echo wp_get_attachment_image( $atts['image'], 'full' ); ?></p>
			<?php elseif ( 'icon' === $atts['type'] && $atts[ $icon_type ] ) : ?>
				<p class="mb-20 black <?php echo esc_attr( $icon_style ); ?>" <?php echo ( $icon_contact ); // WPCS XSS OK. ?>><i class="<?php echo esc_attr( $atts[ $icon_type ] ); ?>" <?php echo ( $icon_color ); // WPCS XSS OK. ?>></i></p>
			<?php endif; ?>

			<?php if ( trim( $atts['title'] ) ) : ?>
				<p class="sport-single__name text-center black <?php echo esc_attr( $white_mode ); ?>"><?php echo esc_html( trim( $atts['title'] ) ); ?></p>
			<?php endif ?>

		</div>
	</div>
<?php endif ?>
